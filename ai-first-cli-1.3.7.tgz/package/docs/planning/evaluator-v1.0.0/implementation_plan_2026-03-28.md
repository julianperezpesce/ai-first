# Plan de Implementación - Evaluator Improvements

**Proyecto:** express-api  
**Score Actual:** 4.40/5.0  
**Score Objetivo:** 4.60-4.80/5.0  
**Fecha:** 2026-03-28  
**Estado:** Planificación

---

## 📊 Análisis del Estado Actual

### Score del Evaluator (última ejecución)
- **Total:** 4.40/5.0 ✅ (Ya supera el objetivo de 4.20)
- **Content Quality:** ~85/100 pts
- **Local Structure:** 40/40 pts

### Issues Identificadas por el Evaluator

1. **Generic Phrases** (Mejora opcional)
   - Reemplazar frases genéricas con descripciones funcionales específicas
   
2. **API Contracts Feature** (Feature disponible)
   - Disponible para Express/NestJS/Spring/FastAPI/Django
   - No obligatorio pero mejora documentación
   
3. **Framework Instructions** (Feature disponible)
   - Disponible para Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
   - Mejora guías específicas del framework
   
4. **Freshness Tracking** (Mantenimiento)
   - Requiere ejecutar `af init` periódicamente
   - No afecta score pero mejora mantenibilidad

---

## 🎯 Plan de Acción

### Fase 1: Análisis y Baseline (15 min)

**Objetivo:** Establecer punto de partida documentado

**Tareas:**
1. [ ] Ejecutar evaluator y guardar resultado completo
2. [ ] Documentar issues específicas encontradas
3. [ ] Crear backup de archivos actuales en `ai-context/`

**Comandos:**
```bash
# Ejecutar evaluator y guardar reporte
node --experimental-modules node_modules/ai-first-evaluator/dist/cli.js \
  --config evaluator.config.json > reports/evaluator-baseline-$(date +%Y%m%d).txt
```

**Entregable:** Reporte baseline guardado

---

### Fase 2: Mejoras de Documentación (45-60 min)

#### 2.1 Mejora: Architecture Components Section

**Archivo:** `test-projects/express-api/ai-context/architecture.md`

**Problema:** Falta sección "Components" requerida por evaluator

**Acciones a implementar:**
1. [ ] Agregar sección `## Components` después de `## Key Modules`
2. [ ] Crear tabla de componentes core:
   - Express Server (Infrastructure)
   - Auth Controller (Controller)
   - User Controller (Controller)
   - Auth Service (Service)
   - User Service (Service)
   - Auth Middleware (Middleware)
   - User Repository (Repository)
3. [ ] Agregar subsección `### Component Interactions` describiendo dependencias

**Template a usar:**
```markdown
## Components

### Core Components

| Component | Type | Responsibility |
|-----------|------|----------------|
| Express Server | Infrastructure | HTTP server initialization and middleware configuration |
| Auth Controller | Controller | Handles authentication endpoints (login, register) |
| User Controller | Controller | Manages user CRUD operations |
| Auth Service | Service | JWT token generation, password validation logic |
| User Service | Service | User business logic, duplicate validation |
| Auth Middleware | Middleware | JWT verification for protected routes |
| User Repository | Repository | In-memory user data storage and retrieval |

### Component Interactions

- **Controllers** depend on **Services** for business logic
- **Services** depend on **Repository** for data access
- **Middleware** intercepts requests before reaching controllers
- **Server** initializes and wires all components together
```

**Validación:**
```bash
node --experimental-modules node_modules/ai-first-evaluator/dist/cli.js \
  --config evaluator.config.json
```

**Criterio de éxito:** Issue "architecture.md missing components section" desaparece del reporte

---

#### 2.2 Mejora: Tech Stack Frameworks Section

**Archivo:** `test-projects/express-api/ai-context/tech_stack.md`

**Problema:** Falta sección "Frameworks" detallada requerida por evaluator

**Acciones a implementar:**
1. [ ] Agregar sección `## Frameworks` antes de `## Development Tools`
2. [ ] Documentar Web Framework (Express.js)
3. [ ] Documentar Authentication Framework (JWT)

**Template a usar:**
```markdown
## Frameworks

### Web Framework
- **Express.js (^4.18.2)** - Core web framework
  - RESTful API routing and middleware support
  - Built-in JSON parsing middleware
  - Extensive ecosystem of middleware plugins

### Authentication Framework
- **JWT (JSON Web Tokens)** - Stateless authentication via jsonwebtoken library
  - Token-based session management
  - Industry standard for API authentication
```

**Validación:**
```bash
node --experimental-modules node_modules/ai-first-evaluator/dist/cli.js \
  --config evaluator.config.json
```

**Criterio de éxito:** Issue "tech_stack.md missing frameworks section" desaparece del reporte

---

#### 2.3 Mejora: Eliminar Frases Genéricas

**Archivos a revisar:**
- `test-projects/express-api/ai-context/summary.md`
- `test-projects/express-api/ai-context/entrypoints.md`
- `test-projects/express-api/ai-context/architecture.md`
- `test-projects/express-api/ai-context/tech_stack.md`

**Frases genéricas a reemplazar:**

| Archivo | Frase Genérica | Sugerencia de Reemplazo |
|---------|----------------|-------------------------|
| architecture.md | "API endpoints and request handling" | "Handles POST /auth/login and POST /auth/register endpoints with JWT validation" |
| architecture.md | "Request/response middleware" | "JWT token verification middleware for protected routes" |
| architecture.md | "Data models and entities" | "User entity definition with in-memory storage operations" |
| architecture.md | "Business logic and use cases" | "Authentication logic with bcrypt password hashing and JWT generation" |
| tech_stack.md | "None detected" (Development Tools) | "nodemon - Development server with hot-reload via `npm run dev`" |

**Proceso:**
1. [ ] Revisar cada archivo línea por línea
2. [ ] Identificar descripciones vagas
3. [ ] Reemplazar con descripciones específicas que mencionen:
   - Nombres de endpoints específicos
   - Tecnologías concretas usadas
   - Funcionalidades exactas

**Validación:**
```bash
node --experimental-modules node_modules/ai-first-evaluator/dist/cli.js \
  --config evaluator.config.json
```

**Criterio de éxito:** Issue "Replace generic phrases with specific functional descriptions" mejora o desaparece

---

### Fase 3: Features Opcionales (30-45 min) - Opcional

#### 3.1 API Contracts

**Acciones:**
1. [ ] Identificar todos los endpoints disponibles en el proyecto
2. [ ] Crear archivo `test-projects/express-api/ai-context/api_contracts.md`
3. [ ] Documentar cada endpoint:
   - Método HTTP
   - Ruta
   - Parámetros (query, body, path)
   - Respuestas posibles
   - Ejemplos de request/response

**Estructura sugerida:**
```markdown
# API Contracts

## Authentication

### POST /auth/login
**Description:** Authenticate user and return JWT token

**Request Body:**
```json
{
  "email": "string",
  "password": "string"
}
```

**Response 200:**
```json
{
  "token": "jwt_token_here",
  "user": { "id": "...", "email": "..." }
}
```

**Response 401:**
```json
{ "error": "Invalid credentials" }
```

### POST /auth/register
...

## Users

### GET /users
...
```

**Endpoints a documentar:**
- POST /auth/login
- POST /auth/register
- GET /users
- GET /users/:id
- POST /users
- PUT /users/:id
- DELETE /users/:id

---

#### 3.2 Framework Instructions

**Acciones:**
1. [ ] Crear archivo `test-projects/express-api/ai-context/framework_instructions.md`
2. [ ] Documentar convenciones específicas de Express.js usadas en el proyecto
3. [ ] Incluir guías para:
   - Estructura de rutas
   - Patrones de middleware
   - Convenciones de nombres
   - Manejo de errores

**Estructura sugerida:**
```markdown
# Framework Instructions - Express.js

## Route Structure
- Routes are defined in `index.js`
- Controllers are separated into `controllers/` directory
- Base path prefixing using Express Router

## Middleware Pattern
- Authentication middleware in `middleware/authMiddleware.js`
- Applied to protected routes using `app.use('/users', authMiddleware)`

## Naming Conventions
- Controllers: `[resource]Controller.js`
- Services: `[resource]Service.js`
- Middleware: `[purpose]Middleware.js`

## Error Handling
- Use try-catch in async controller methods
- Return consistent error format: `{ error: string }`
```

---

### Fase 4: Verificación Final (15-20 min)

**Objetivo:** Validar que todas las mejoras cumplen objetivos

**Checklist:**
- [ ] Ejecutar evaluator y verificar score ≥ 4.0
- [ ] Confirmar que no hay regresiones
- [ ] Validar formato markdown de todos los archivos
- [ ] Verificar consistencia entre archivos

**Comandos:**
```bash
# Evaluación final
node --experimental-modules node_modules/ai-first-evaluator/dist/cli.js \
  --config evaluator.config.json

# Comparar con baseline
diff reports/evaluator-baseline-*.txt reports/evaluator-final-*.txt
```

**Criterios de éxito:**
- Score final ≥ 4.0 (objetivo: 4.20+)
- Nuevas issues de severity HIGH: 0
- Nuevas issues de severity MEDIUM: ≤ 2

---

### Fase 5: Documentación (10 min)

**Acciones:**
1. [ ] Actualizar CHANGELOG.md con cambios realizados
2. [ ] Actualizar `docs/planning/evaluator-v1.0.0/improvements_plan_2026-03-28.md` con resultados
3. [ ] Crear commit con mensaje descriptivo

**Template commit:**
```
docs(express-api): improve ai-context documentation quality

- Add Components section to architecture.md
- Add Frameworks section to tech_stack.md  
- Replace generic phrases with specific descriptions
- [Optional] Add API contracts documentation
- [Optional] Add Framework instructions

Score improvement: X.XX → Y.YY (+Z.ZZ)
```

---

## 📋 Resumen de Tareas

| Fase | Tarea | Tiempo Est. | Prioridad |
|------|-------|-------------|-----------|
| 1 | Ejecutar baseline y documentar | 15 min | Alta |
| 2.1 | Agregar Components section | 20 min | Alta |
| 2.2 | Agregar Frameworks section | 15 min | Alta |
| 2.3 | Eliminar frases genéricas | 20 min | Media |
| 3.1 | [Opcional] API Contracts | 30 min | Baja |
| 3.2 | [Opcional] Framework Instructions | 15 min | Baja |
| 4 | Verificación final | 15 min | Alta |
| 5 | Documentación | 10 min | Media |
| | **Total (sin opcionales)** | **~1.5 horas** | |
| | **Total (con opcionales)** | **~2.5 horas** | |

---

## 🎯 Escenarios de Implementación

### Escenario A: Mínimo Viable (1.5 horas)
Implementar solo Fases 1, 2.1, 2.2, 4, 5
- Score esperado: 4.60-4.70
- Riesgo: Bajo
- Esfuerzo: Medio

### Escenario B: Completo (2.5 horas)
Implementar todas las fases incluyendo opcionales
- Score esperado: 4.70-4.90
- Riesgo: Medio
- Esfuerzo: Alto

### Escenario C: Iterativo
Implementar Escenario A, luego evaluar si se necesita Escenario B
- Score inicial: 4.60+
- Decisión puntual basada en resultados

---

## ⚠️ Riesgos y Mitigaciones

| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|-------------|---------|------------|
| Score no mejora como esperado | Media | Alto | Ejecutar evaluator después de cada cambio mayor |
| Regresiones en documentación | Baja | Medio | Crear backup antes de modificar |
| Inconsistencias entre archivos | Media | Medio | Revisar todos los archivos después de cambios |
| Tiempo excedido | Media | Bajo | Seguir orden de prioridad, opcionales al final |

---

## 📚 Referencias

- **Handoff Original:** `docs/planning/HANDOFF_EVALUATOR_IMPROVEMENTS_2026-03-28.md`
- **Plan de Mejoras:** `docs/planning/evaluator-v1.0.0/improvements_plan_2026-03-28.md`
- **Evaluator Config:** `evaluator.config.json`
- **Guía Evaluator:** `node_modules/ai-first-evaluator/README.md`

---

## ✅ Checklist Pre-Implementación

- [ ] Leer completamente este plan
- [ ] Decidir escenario (A, B o C)
- [ ] Tener acceso a ejecutar evaluator
- [ ] Verificar que archivos `ai-context/` existen
- [ ] Crear directorio `reports/` si no existe
- [ ] Tener permisos para modificar archivos en `test-projects/express-api/ai-context/`

---

**Plan creado:** 2026-03-28  
**Versión:** 1.0  
**Estado:** Listo para ejecución
