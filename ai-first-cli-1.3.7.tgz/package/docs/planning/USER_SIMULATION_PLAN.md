# Plan de Simulación de Usuario - ai-first v1.4.0

> **Validación de features antes del release v1.4.0**
> **Fecha:** Marzo 2026
> **Objetivo:** Identificar bugs y problemas de UX antes del lanzamiento

---

## 🎯 Perfiles de Usuario a Simular

### Perfil 1: "Developer Individual"
- **Contexto:** Desarrollador solitario trabajando en proyecto personal
- **Necesidad:** Reducir costos de API al usar AI
- **Flujo esperado:** 
  1. Instala ai-first
  2. Usa preset "quick" para iteraciones rápidas
  3. Comprime código para reducir tokens

### Perfil 2: "Tech Lead en Equipo"
- **Contexto:** Lidera equipo de 5 desarrolladores
- **Necesidad:** Estandarizar configuración del proyecto
- **Flujo esperado:**
  1. Crea `ai-first.config.json` en el repo
  2. Define presets para diferentes tareas
  3. Onboarding de nuevos devs

### Perfil 3: "Arquitecto de Microservicios"
- **Contexto:** Mantiene 10+ microservicios
- **Necesidad:** Contexto unificado entre servicios
- **Flujo esperado:**
  1. Escanea múltiples repos
  2. Ve dependencias cross-repo
  3. Debuggear issues que cruzan servicios

### Perfil 4: "Usuario de AI Agents"
- **Contexto:** Usa Cursor/Claude Code diariamente
- **Necesidad:** Integración nativa con AI agents
- **Flujo esperado:**
  1. Configura MCP server
  2. Pide al AI que "encuentre función de auth"
  3. El AI usa RAG para buscar

---

## 🧪 Escenarios de Prueba

### Escenario 1: Instalación y Configuración

**Setup inicial:**
```bash
# Limpiar instalación previa
npm uninstall -g ai-first-cli
rm -rf ~/.config/ai-first  # si existe

# Instalar nueva versión
npm install -g ai-first-cli@latest

# Verificar versión
af --version  # Debe mostrar 1.4.0
```

**Prueba A: Uso básico sin config**
```bash
mkdir test-project
cd test-project
# Crear algunos archivos de prueba
echo 'console.log("hello")' > index.js
mkdir src
echo 'export const foo = () => {}' > src/utils.js

# Probar comando básico
af init

# Verificar que se creó ai-context/
ls ai-context/
```

**Resultado esperado:** ✅ Contexto generado sin errores

---

### Escenario 2: Configuration System

**Prueba B: Crear archivo de configuración**
```bash
cat > ai-first.config.json << 'EOF'
{
  "version": "1.0",
  "preset": "quick",
  "analysis": {
    "detailLevel": "signatures"
  },
  "output": {
    "directory": "custom-context"
  }
}
EOF

af init

# Verificar que usó el directorio custom
ls custom-context/
```

**Prueba C: Probar presets**
```bash
# Probar cada preset
af init --preset full
af init --preset quick
af init --preset api
af init --preset docs

# Verificar diferencias en output
```

**Resultado esperado:** ✅ Cada preset genera contexto diferente

---

### Escenario 3: Library/API Mode

**Prueba D: Usar como librería**
```bash
mkdir test-library-usage
cd test-library-usage
npm init -y
npm install ai-first-cli

# Crear script de prueba
cat > test.js << 'EOF'
import { loadConfig, processContent, classifyFile } from 'ai-first-cli';

console.log('Test 1: loadConfig');
const result = loadConfig({ configPath: './test-config.json' });
console.log('Config loaded:', result.source);

console.log('\nTest 2: processContent');
const code = 'function test() { return 42; }';
const processed = processContent(code, { detailLevel: 'signatures' });
console.log('Compression ratio:', processed.compressionRatio);

console.log('\nTest 3: classifyFile');
const level = classifyFile(
  'src/utils.js',
  ['src/**/*'],
  ['node_modules/**/*'],
  ['assets/**/*'],
  ['**/*.test.js']
);
console.log('Classification:', level);
EOF

node test.js
```

**Resultado esperado:** ✅ Todos los imports funcionan y retornan datos válidos

---

### Escenario 4: Content Compression

**Prueba E: Comprimir código real**
```bash
# Crear archivo de prueba con funciones
cat > src/test-file.ts << 'EOF'
/**
 * Calculates the total price of items in cart
 * @param items - Array of cart items
 * @returns Final price
 */
export function calculateTotal(items: CartItem[]): number {
  let subtotal = items.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);
  
  const tax = subtotal * 0.08;
  return subtotal + tax;
}

export function applyDiscount(amount: number, code: string): number {
  const discounts: Record<string, number> = {
    'SAVE10': 0.10,
    'SAVE20': 0.20
  };
  return amount * (discounts[code] || 0);
}
EOF

# Crear script para probar compresión
cat > test-compression.js << 'EOF'
import { processContent } from 'ai-first-cli';
import fs from 'fs';

const content = fs.readFileSync('./src/test-file.ts', 'utf-8');

console.log('=== Original ===');
console.log(`Size: ${content.length} chars`);
console.log(`Tokens: ${Math.ceil(content.length / 4)}`);

console.log('\n=== Signatures Mode ===');
const sigResult = processContent(content, { detailLevel: 'signatures' });
console.log(`Size: ${sigResult.processedLength} chars (${sigResult.compressionRatio.toFixed(1)}% reduction)`);
console.log(`Tokens: ${sigResult.tokens}`);
console.log('\nOutput preview:');
console.log(sigResult.content.slice(0, 500));

console.log('\n=== Skeleton Mode ===');
const skelResult = processContent(content, { detailLevel: 'skeleton' });
console.log(`Size: ${skelResult.processedLength} chars (${skelResult.compressionRatio.toFixed(1)}% reduction)`);
console.log(`Tokens: ${skelResult.tokens}`);
console.log('\nOutput preview:');
console.log(skelResult.content.slice(0, 500));
EOF

node test-compression.js
```

**Resultado esperado:** ✅ 
- Signatures mode reduce ~70%
- Skeleton mode reduce ~90%
- Preserva imports/exports

---

### Escenario 5: Git Blame

**Prueba F: Integrar blame en output**
```bash
# En un repo git real
cd /mnt/m2/Código/opencode-ai-first  # o cualquier repo

cat > test-blame.js << 'EOF'
import { getGitBlame, formatGitBlame } from 'ai-first-cli';

const result = getGitBlame('.', 'src/index.ts');

console.log('Git Blame Result:');
console.log(`File: ${result.filePath}`);
console.log(`Lines: ${result.lines.length}`);
console.log('\nAuthors:');
for (const [author, count] of result.authors) {
  console.log(`  ${author}: ${count} lines`);
}

console.log('\n=== Inline Format (primeras 5 líneas) ===');
const inline = formatGitBlame(result, 'inline');
console.log(inline.split('\n').slice(0, 5).join('\n'));
EOF

node test-blame.js
```

**Resultado esperado:** ✅ 
- Muestra autores
- Formato inline funciona
- Fechas y hashes presentes

---

### Escenario 6: MCP Server

**Prueba G: Iniciar MCP server**
```bash
# Probar que el servidor inicia sin errores
af mcp-server &
SERVER_PID=$!

# Esperar un segundo
sleep 1

# Verificar que el proceso está corriendo
ps aux | grep mcp-server

# Matar el proceso
kill $SERVER_PID
```

**Resultado esperado:** ✅ Servidor inicia sin errores

---

### Escenario 7: RAG Vector Search

**Prueba H: Crear índice y buscar**
```bash
cat > test-rag.js << 'EOF'
import { createVectorIndex, semanticSearch } from 'ai-first-cli';
import fs from 'fs';

const index = createVectorIndex('./test-vector-index.json');

// Indexar algunos documentos
const docs = [
  {
    id: '1',
    content: 'function authenticateUser(username, password) { /* auth logic */ }',
    embedding: Array(100).fill(0).map(() => Math.random()),
    metadata: { filePath: 'src/auth.js', type: 'function' }
  },
  {
    id: '2', 
    content: 'function calculateTotal(items) { /* payment logic */ }',
    embedding: Array(100).fill(0).map(() => Math.random()),
    metadata: { filePath: 'src/payment.js', type: 'function' }
  }
];

docs.forEach(doc => index.addDocument(doc));
index.save();

console.log('Indexed 2 documents');

// Buscar
const results = semanticSearch(index, 'user authentication', 2);
console.log('\nSearch results for "user authentication":');
results.forEach(r => {
  console.log(`  - ${r.document.metadata.filePath} (score: ${r.score.toFixed(2)})`);
});
EOF

node test-rag.js
```

**Resultado esperado:** ✅ Búsqueda retorna resultados ordenados por score

---

### Escenario 8: Multi-Repository

**Prueba I: Escanear múltiples repos**
```bash
# Crear estructura de microservicios simulada
mkdir -p test-microservices
cd test-microservices

mkdir -p frontend/src backend-api/src shared-lib/src

# Frontend
echo '{"name": "frontend", "dependencies": {"shared-lib": "file:../shared-lib"}}' > frontend/package.json
echo 'import { utils } from "shared-lib";' > frontend/src/app.js

# Backend  
echo '{"name": "backend-api", "dependencies": {"shared-lib": "file:../shared-lib"}}' > backend-api/package.json
echo 'const utils = require("shared-lib");' > backend-api/src/server.js

# Shared lib
echo '{"name": "shared-lib"}' > shared-lib/package.json
echo 'export const utils = {};' > shared-lib/src/index.js

cat > test-multirepo.js << 'EOF'
import { scanMultiRepo, generateMultiRepoReport } from 'ai-first-cli';

const context = scanMultiRepo({
  repositories: ['./frontend', './backend-api', './shared-lib'],
  includeSubmodules: false
});

console.log('Multi-Repo Context:');
console.log(`Repositories: ${context.repositories.length}`);
console.log(`Total files: ${context.totalFiles}`);

console.log('\nCross-repo dependencies:');
for (const [repo, deps] of context.crossRepoDependencies) {
  console.log(`  ${repo} -> ${deps.join(', ')}`);
}

const report = generateMultiRepoReport(context);
console.log('\n=== Report ===');
console.log(report);
EOF

node test-multirepo.js
```

**Resultado esperado:** ✅ 
- Detecta los 3 repositorios
- Muestra archivos por repo
- Detecta dependencias (frontend/backend dependen de shared-lib)

---

## 🐛 Lista de Verificación de Bugs

### Critical (Bloquean release)
- [ ] Build falla (`npm run build`)
- [ ] Comando `af init` crashea
- [ ] Imports de librería no funcionan
- [ ] MCP server no inicia

### High (Degradan UX)
- [ ] Config file no es leído
- [ ] Presets no aplican correctamente
- [ ] Compresión no reduce tamaño
- [ ] Git blame no muestra autores

### Medium (Nice to fix)
- [ ] Performance lento en repos grandes
- [ ] Mensajes de error poco claros
- [ ] Documentación incompleta

### Low (Cosméticos)
- [ ] Typos en mensajes
- [ ] Formato inconsistente

---

## 📊 Resultados de Simulación

### Resumen de Pruebas

| Escenario | Estado | Bugs Encontrados | Notas |
|-----------|--------|------------------|-------|
| 1: Instalación | ⏳ Pendiente | - | - |
| 2: Config System | ⏳ Pendiente | - | - |
| 3: Library/API | ⏳ Pendiente | - | - |
| 4: Compression | ⏳ Pendiente | - | - |
| 5: Git Blame | ⏳ Pendiente | - | - |
| 6: MCP Server | ⏳ Pendiente | - | - |
| 7: RAG Search | ⏳ Pendiente | - | - |
| 8: Multi-Repo | ⏳ Pendiente | - | - |

### Bugs Encontrados

#### Bug #1: [Título]
- **Severidad:** Critical/High/Medium/Low
- **Escenario:** [Cuál prueba lo encontró]
- **Pasos para reproducir:**
  1. Paso 1
  2. Paso 2
- **Comportamiento esperado:** 
- **Comportamiento actual:**
- **Fix propuesto:**

---

## ✅ Criterios de Aceptación

Para considerar v1.4.0 listo para release:

### Must Have (100% requerido)
- [ ] Todos los escenarios críticos pasan
- [ ] 0 bugs Critical
- [ ] Build exitoso
- [ ] Tests unitarios pasan

### Should Have (80%+ requerido)
- [ ] 80% de escenarios high pasan
- [ ] ≤ 2 bugs High
- [ ] Documentación completa

### Nice to Have (50%+)
- [ ] 50% de escenarios medium pasan
- [ ] Performance aceptable

---

## 🚀 Próximos Pasos

1. **Ejecutar todas las simulaciones** documentadas arriba
2. **Documentar bugs encontrados** en formato estructurado
3. **Priorizar fixes** según severidad
4. **Repetir simulaciones** después de fixes
5. **Decisión Go/No-Go** para release

---

**Nota:** Este documento debe actualizarse con los resultados reales de cada simulación.
