# 📘 Guía de Features de ai-first-cli - Qué son y para qué sirven

> **Documento de producto** explicando cada mejora de forma clara y práctica  
> **Público objetivo:** Usuarios y desarrolladores que usan AI agents  
> **Fecha:** Marzo 2026

---

## 🎯 Resumen Ejecutivo

ai-first-cli está evolucionando de un simple "empaquetador de código" a una **plataforma completa de contexto para AI agents**. Cada feature resuelve un problema real que enfrentan los desarrolladores al trabajar con AI.

### Los 3 Problemas Fundamentales que Resolvemos

1. **📦 "Contexto saturado"** - Los AI agents reciben demasiados tokens innecesarios
2. **🔍 "Falta de contexto específico"** - El AI no sabe qué partes del código son relevantes  
3. **🌐 "Integración fragmentada"** - Cada AI agent usa su propio formato

---

## 🏗️ FASE 1: Fundamentos (Ya Implementada)

### 1.1 Library/API Mode - "Usa ai-first como librería"

#### ¿Qué es?
Permite importar ai-first-cli como un módulo de Node.js en tus propios scripts y aplicaciones.

#### ¿Qué problema resuelve?
**Antes:** ai-first solo funcionaba como CLI. Si querías integrarlo en tu propia herramienta, tenías que ejecutar procesos externos.

**Después:** Puedes usar ai-first directamente desde código:
```typescript
import { loadConfig, runAIFirst } from 'ai-first-cli';

// En tu propia aplicación
const { config } = loadConfig({ preset: 'api' });
const result = await runAIFirst({ 
  rootDir: './my-project',
  outputDir: './docs/context'
});
```

#### Casos de uso reales:
- **IDEs y editores:** Plugin de VS Code que genera contexto automáticamente
- **CI/CD pipelines:** Generar contexto antes de correr tests
- **Herramientas internas:** Tu empresa quiere generar docs técnicos automáticamente
- **Testing:** Testear que tu código genera el contexto correcto

#### Beneficio concreto:
Los desarrolladores pueden construir **herramientas encima de ai-first**, no solo usarlo directamente.

---

### 1.2 Sistema de Configuración (`ai-first.config.json`)

#### ¿Qué es?
Un archivo de configuración JSON donde defines cómo quieres que se genere el contexto para tu proyecto.

#### ¿Qué problema resuelve?
**Antes:** Tenías que recordar y escribir largos comandos cada vez:
```bash
af init --include "src/**/*" --exclude "**/*.test.ts" --exclude "**/node_modules/**" --output ./docs/ai
```

**Después:** Solo escribes una vez:
```bash
af init  # Lee automáticamente ai-first.config.json
```

#### Ejemplo de configuración:
```json
{
  "version": "1.0",
  "files": {
    "include": ["src/**/*", "lib/**/*"],
    "exclude": ["**/*.test.*", "**/node_modules/**"]
  },
  "output": {
    "dir": "ai-context",
    "detailLevel": "full"
  }
}
```

#### Beneficio concreto:
- ✅ **Reproducibilidad:** Todos en el equipo usan la misma configuración
- ✅ **Version control:** La config vive en git
- ✅ **Simplicidad:** Un comando corto hace todo

---

### 1.3 Presets (Configuraciones Predefinidas)

#### ¿Qué es?
Plantillas de configuración para diferentes escenarios comunes.

#### Los 4 presets incluidos:

**`full`** - "Todo el proyecto"
```bash
af init --preset full
# Incluye todo excepto node_modules y .git
```
*Útil para:* Proyectos pequeños o cuando necesitas análisis completo

**`quick`** - "Solo el código fuente"
```bash
af init --preset quick
# Solo src/, lib/, app/ - sin tests
```
*Útil para:* Iteraciones rápidas, cambios menores

**`api`** - "Foco en la API"
```bash
af init --preset api
# Solo routes, controllers, services, middleware
```
*Útil para:* Cuando trabajas en endpoints o lógica de backend

**`docs`** - "Solo documentación"
```bash
af init --preset docs
# Solo .md, README, CHANGELOG, LICENSE
```
*Útil para:* Mejorar documentación, onboarding de nuevos devs

#### ¿Qué problema resuelve?
**Antes:** Cada vez que cambias de tarea, tienes que recordar qué archivos son relevantes.

**Después:** Seleccionas el preset apropiado y obtienes el contexto perfecto para esa tarea.

#### Beneficio concreto:
- ⚡ **Velocidad:** No pensar en qué incluir
- 🎯 **Precisión:** Contexto optimizado para cada tipo de trabajo
- 📚 **Estándares:** Toda la empresa usa los mismos presets

#### Presets personalizados:
```json
{
  "presets": {
    "backend-only": {
      "name": "backend-only",
      "description": "Solo el backend, sin frontend",
      "files": {
        "include": ["server/**/*", "api/**/*", "models/**/*"]
      }
    }
  }
}
```

---

## 🔧 FASE 2: Control de Contenido (Próxima)

### 2.1 Niveles de Inclusión (Full/Compress/Directory)

#### ¿Qué es?
Un sistema de 3 niveles para decidir QUÉ TANTO de cada archivo incluir:

- **Full:** Todo el contenido del archivo
- **Compress:** Solo imports, exports y signatures (sin cuerpo de funciones)
- **Directory:** Solo el nombre en la estructura de directorios

#### ¿Qué problema resuelve?
**El problema real:** Los proyectos tienen archivos de diferentes "valores" para el AI:

```
📁 Mi Proyecto
├── 📄 src/auth/login.ts          ← MI CÓDIGO (alta relevancia)
├── 📄 src/utils/helpers.ts       ← MI CÓDIGO (media relevancia)
├── 📦 node_modules/lodash/*.js   ← LIBRERÍA (baja relevancia)
└── 🖼️  assets/images/logo.png    ← ASSET (muy baja relevancia)
```

**Antes:** Todo se incluía igual, desperdiciando tokens.

**Después:** Cada tipo de archivo se incluye apropiadamente:

```json
{
  "files": {
    "include": ["src/**/*.ts"],           // Full content
    "compress": ["node_modules/**/*.d.ts"], // Solo tipos
    "directory": ["assets/**"]             // Solo nombres
  }
}
```

#### Ejemplo práctico:

**Input:** Archivo `src/utils/dateHelpers.ts`
```typescript
// FULL content
export function formatDate(date: Date, format: string): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  
  return format
    .replace('YYYY', String(year))
    .replace('MM', month)
    .replace('DD', day);
}

export function parseDate(dateString: string): Date {
  return new Date(dateString);
}
```

**COMPRESS output (solo lo esencial):**
```typescript
// Solo imports/exports y signatures
export function formatDate(date: Date, format: string): string;
export function parseDate(dateString: string): Date;
```

#### Beneficio concreto:
- 📉 **Reducción de 40-70% en tokens** usados
- 💰 **Menor costo** en APIs de AI (OpenAI, Anthropic, etc.)
- ⚡ **Respuestas más rápidas** del AI
- 🎯 **Mejor precisión** porque el AI no se distrae con código irrelevante

#### Casos de uso:

**Microservicios:**
```json
{
  "files": {
    "include": ["src/**/*"],
    "compress": ["shared-lib/**/*"],
    "directory": ["node_modules/@company/shared-utils"]
  }
}
```

**Monorepo:**
```json
{
  "files": {
    "include": ["apps/web/**/*", "packages/ui/**/*"],
    "compress": ["packages/utils/**/*"],
    "directory": ["apps/docs/**"]
  }
}
```

---

### 2.2 Code Detail Levels (Nivel de Detalle del Código)

#### ¿Qué es?
Controla qué tan detallado es el contenido de cada archivo:

- **`full`** - Código completo (comportamiento actual)
- **`signatures`** - Solo firmas de funciones y documentación
- **`skeleton`** - Solo imports/exports (estructura mínima)

#### ¿Qué problema resuelve?

**Escenario 1: "Solo quiero entender la API"**
- No necesitas ver el cuerpo de cada función
- Solo necesitas saber: ¿qué funciones existen? ¿qué parámetros aceptan? ¿qué retornan?

**Escenario 2: "Trabajando en arquitectura"**
- No necesitas ver implementaciones
- Solo necesitas la estructura: clases, interfaces, relaciones

**Escenario 3: "Debugging específico"**
- Ahí SÍ necesitas el código completo

#### Ejemplo visual:

**Código original:**
```typescript
/**
 * Calculates the total price of items in cart
 * @param items - Array of cart items
 * @param discountCode - Optional discount code
 * @returns Final price after discounts
 */
export function calculateCartTotal(
  items: CartItem[], 
  discountCode?: string
): number {
  let subtotal = items.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);
  
  if (discountCode) {
    const discount = applyDiscount(subtotal, discountCode);
    subtotal -= discount;
  }
  
  const tax = subtotal * 0.08;
  return subtotal + tax;
}

function applyDiscount(amount: number, code: string): number {
  // Complex discount logic here
  const discounts: Record<string, number> = {
    'SAVE10': 0.10,
    'SAVE20': 0.20,
    'VIP': 0.30
  };
  return amount * (discounts[code] || 0);
}
```

**Modo `full` (comportamiento actual):**
```typescript
// ... todo el código de arriba ...
```
*Tokens: ~800*

**Modo `signatures`:**
```typescript
/**
 * Calculates the total price of items in cart
 * @param items - Array of cart items
 * @param discountCode - Optional discount code
 * @returns Final price after discounts
 */
export function calculateCartTotal(
  items: CartItem[], 
  discountCode?: string
): number;
```
*Tokens: ~150* **(81% reducción)**

**Modo `skeleton`:**
```typescript
export function calculateCartTotal(items: CartItem[], discountCode?: string): number;
```
*Tokens: ~20* **(97% reducción)**

#### Beneficio concreto:
- 📚 **Documentación automática:** Genera "API docs" de tu código
- 🧠 **Entendimiento rápido:** Ve la estructura sin el ruido
- 💼 **Onboarding:** Nuevos devs entienden el codebase en minutos
- 🔍 **Planning:** Discute arquitectura sin ver implementaciones

#### Cuándo usar cada modo:

| Modo | Tokens | Cuándo usar |
|------|--------|-------------|
| `full` | 100% | Debugging, implementación, testing |
| `signatures` | ~20% | Planning, API review, documentación |
| `skeleton` | ~3% | Overview, onboarding, estimación |

---

## 🔌 FASE 3: Integraciones (Próxima)

### 3.1 Git Blame Integration

#### ¿Qué es?
Agrega información de autoría (quién escribió qué y cuándo) junto al código.

#### ¿Qué problema resuelve?
**Escenario típico:**
> "Este código tiene un bug. ¿Quién lo escribió? ¿Por qué se hizo así?"

**Antes:**
1. Encuentras el bug
2. Usas `git blame` manualmente
3. Buscas el autor
4. Luego preguntas al AI sin contexto

**Después:**
```typescript
[julianperezpesce 2025-02-17] function calculateTotal(items: Item[]): number {
[julianperezpesce 2025-04-19]   return items.reduce((sum, item) => sum + item.price, 0);
[julianperezpesce 2025-02-17] }
```

El AI ahora puede decir:
> "Este código fue escrito por Julian en febrero y modificado en abril. El cambio reciente sugiere que están sumando precios..."

#### Beneficio concreto:
- 👥 **Responsabilidad:** Sabes quién preguntar sobre el código
- 📅 **Contexto temporal:** "Este código es de 2 años atrás, quizás necesita actualización"
- 🔄 **Tracking de cambios:** El AI sugiere quién revisó qué

#### Caso de uso: Code Review
```bash
af init --git-blame
# El AI puede sugerir: 
# "Este archivo fue modificado por 3 personas distintas en el último mes.
# Considera agregar más tests para prevenir regressions."
```

---

### 3.2 MCP Server Support (Model Context Protocol)

#### ¿Qué es?
Un servidor que permite a los AI agents (Cursor, Claude, OpenCode) comunicarse directamente con ai-first-cli.

#### ¿Qué problema resuelve?

**El problema:** Cada AI agent tiene su propia forma de pedir contexto.

**Cursor:** Usa archivos `.cursorrules`
**Claude Code:** Contexto en system prompt
**OpenCode:** Comandos personalizados
**VS Code Copilot:** Su propio sistema

**Resultado:** Tienes que configurar cada AI agent por separado. 😫

#### La solución MCP:
MCP es un protocolo estándar (creado por Anthropic) para que AI agents descubran y usen herramientas.

**Cómo funciona:**
```bash
# Inicias el servidor MCP de ai-first
af mcp-server

# Ahora los AI agents pueden hacer:
- "Generate context for my auth module"
- "Find all functions that use the database"
- "Show me the architecture of this project"
```

#### Ejemplo práctico con Cursor:

**Configuración en Cursor (.cursor/mcp.json):**
```json
{
  "mcpServers": {
    "ai-first": {
      "command": "af",
      "args": ["mcp-server"]
    }
  }
}
```

**Uso en Cursor:**
```
Usuario: "Quiero agregar autenticación OAuth a mi app"

Cursor (usando MCP): 
1. Llama a ai-first: "get_architecture"
2. Descubre que usas Express + Passport
3. Responde: "Veo que tienes Express con Passport. Para OAuth necesitas:
   - Agregar passport-google-oauth20
   - Crear ruta /auth/google en src/routes/auth.js
   - ..."
```

#### Beneficio concreto:
- 🔌 **Universal:** Funciona con cualquier AI agent que soporte MCP
- 🧠 **Inteligente:** El AI puede preguntar específicamente lo que necesita
- ⚡ **Automático:** No más copy-paste de contexto manual
- 🔄 **Tiempo real:** El AI siempre ve el código actualizado

#### Tools que proporcionará ai-first:
1. **`generate_context`** - Generar contexto para un módulo específico
2. **`query_symbols`** - Buscar funciones/clases específicas
3. **`get_architecture`** - Obtener arquitectura del proyecto
4. **`explore_dependencies`** - Ver dependencias entre módulos
5. **`get_recent_changes`** - Qué cambió recientemente

---

## 🧠 FASE 4: Features Avanzadas (Futuro)

### 4.1 RAG Vector Local (Retrieval Augmented Generation)

#### ¿Qué es?
Un sistema de búsqueda semántica que permite preguntar cosas como:
- "Dónde está la función de login?"
- "Qué archivos manejan pagos?"
- "Cómo se implementa la autenticación?"

Y obtener respuestas basadas en el **significado**, no solo en coincidencias de texto.

#### ¿Qué problema resuelve?

**Problema:** Los proyectos grandes son difíciles de navegar.

**Escenario:** Estás en un proyecto nuevo con 500 archivos. Necesitas encontrar "dónde se maneja la autenticación".

**Opciones actuales:**
1. 🔍 Búsqueda de texto: Busca "auth", "login", "authentication"
   - Problema: Encuentra TODO lo relacionado, incluso comentarios
   
2. 🗺️ Explorar manual: Abres carpetas una por una
   - Problema: Toma horas en proyectos grandes

3. 🤖 Preguntar al AI: "Lee todo el proyecto y dime..."
   - Problema: Miles de tokens, costoso y lento

#### La solución RAG:

**Paso 1 (una vez):** Indexamos todo tu código con embeddings
```bash
af index --semantic
```

**Paso 2 (cuando necesites):** Buscas con lenguaje natural
```bash
af query --semantic "funciones relacionadas con autenticación de usuarios"
```

**Resultado:** Obtienes los 5-10 archivos más relevantes, no todo el proyecto.

#### Cómo funciona (simplificado):

```
"Funciones de autenticación" 
      ↓
[Embedding Model] 
      ↓
Vector: [0.23, -0.45, 0.89, ...]
      ↓
[Base de datos vectorial]
      ↓
"Archivos más similares:"
- src/auth/login.ts (95% match)
- src/middleware/auth.ts (87% match)
- src/services/userService.ts (72% match)
```

#### Beneficio concreto:
- 🎯 **Precisión:** Encuentra el código relevante, no todo lo que contiene "auth"
- ⚡ **Velocidad:** Respuestas en milisegundos, no segundos
- 💰 **Económico:** Solo envías al AI los archivos relevantes (no todo)
- 🔒 **Privacidad:** Todo es local, no envías código a servidores externos

#### Competencia:
- **Context7:** Hace esto pero es cloud-based (tienes que enviar tu código a ellos)
- **ai-first:** Lo hace 100% local en tu máquina

#### Casos de uso:

**1. Onboarding de nuevos desarrolladores:**
```bash
# Nuevo dev pregunta:
af query --semantic "cómo funciona el sistema de pagos"

# Obtiene:
# - src/payments/stripeService.ts
# - src/routes/payment.ts
# - docs/payments.md
```

**2. Debugging:**
```bash
# Error: "User not authenticated"
af query --semantic "middleware de autenticación errores"

# Obtiene archivos relacionados con auth middleware
```

**3. Code Review:**
```bash
af query --semantic "todas las funciones que usan la base de datos"
# Revisar que todas hagan sanitización correcta
```

---

### 4.2 Multi-Repositorio / Monorepos

#### ¿Qué es?
Soporte para generar contexto que abarque **múltiples repositorios** relacionados.

#### ¿Qué problema resuelve?

**Arquitectura moderna = Múltiples repos:**
```
📦 my-company/
├── 📁 frontend/          # React app
├── 📁 backend-api/       # Express API
├── 📁 shared-libs/       # Librerías compartidas
├── 📁 mobile-app/        # React Native
└── 📁 infrastructure/    # Terraform, Docker
```

**Problema:** 
- Una feature toca frontend + backend + shared-libs
- El AI necesita ver todo para entender el cambio
- Pero cada repo es independiente

**Antes:**
```bash
cd frontend && af init
cd ../backend-api && af init
cd ../shared-libs && af init
# Ahora tienes 3 contextos separados... 
# y el AI no ve las conexiones entre ellos
```

**Después:**
```bash
af init --repos ./frontend,./backend-api,./shared-libs
# Contexto unificado que muestra conexiones entre repos
```

#### Ejemplo de output:

```markdown
# Cross-Repository Context

## Repositories
- **frontend** (React app) - 45 files
- **backend-api** (Express) - 32 files  
- **shared-libs** (TypeScript) - 12 files

## Cross-Repository Dependencies
```
frontend/src/api/client.ts → shared-libs/src/types/api.ts
backend-api/src/routes/users.ts → shared-libs/src/types/user.ts
```

## Entry Points
- **Frontend:** src/App.tsx
- **API:** src/server.ts
```

#### Beneficio concreto:
- 🌐 **Visibilidad total:** El AI ve todo el sistema, no solo un repo
- 🔗 **Conexiones claras:** Detecta dependencias entre servicios
- 🐛 **Debugging completo:** Un bug en frontend puede ser del backend
- 📋 **Planning:** Cambios que afectan múltiples repos

#### Casos de uso:

**Microservicios:**
```bash
af init --repos ./auth-service,./payment-service,./user-service
# Contexto de cómo los 3 servicios interactúan
```

**Frontend + Backend:**
```bash
af init --repos ./web-app,./api-server
# El AI sugiere cambios coordinados en ambos lados
```

**Git Submodules:**
```bash
af init --include-submodules
# Incluye automáticamente los submódulos de git
```

---

## 📊 Comparativa: Antes vs Después

### Escenario: "Agregar feature de notificaciones"

| Aspecto | Antes (v1.3.x) | Después (con todas las mejoras) |
|---------|----------------|----------------------------------|
| **Tokens usados** | 15,000 | 3,500 (77% reducción) |
| **Tiempo de setup** | 5 min (escribir comandos) | 10 seg (usar preset `api`) |
| **Contexto relevante** | Todo el proyecto | Solo módulos relacionados |
| **Integración con AI** | Copy-paste manual | MCP server automático |
| **Búsqueda de código** | Grep manual | RAG semántico |
| **Multi-repo** | Contextos separados | Contexto unificado |

### Escenario: "Nuevo desarrollador en el equipo"

| Tarea | Antes | Después |
|-------|-------|---------|
| Entender arquitectura | Días leyendo código | Minutos con `skeleton` mode |
| Encontrar donde trabajar | Horas explorando | Segundos con RAG search |
| Ver quién sabe qué | Preguntar a todos | Git blame integrado |
| Primer PR exitoso | Semana 2 | Día 2-3 |

---

## 🎯 Roadmap y Prioridades

### ✅ Completado (FASE 1)
- [x] Library/API Mode
- [x] Config System
- [x] Presets (full, quick, api, docs)

### 🔄 Próximo (FASE 2)
- [ ] Niveles de Inclusión (70% reducción de tokens)
- [ ] Code Detail Levels (signatures/skeleton)
- **Impacto:** Proyectos grandes ahora son manejables

### ⏳ Futuro cercano (FASE 3)
- [ ] Git Blame
- [ ] MCP Server
- **Impacto:** Integración perfecta con todos los AI agents

### 🔮 Futuro avanzado (FASE 4)
- [ ] RAG Vector Local
- [ ] Multi-Repositorio
- **Impacto:** Transforma ai-first en plataforma completa

---

## 💡 Cómo Aprovechar Cada Feature

### Si eres Developer Individual:
1. **Usa presets:** `af init --preset quick` para iteraciones rápidas
2. **Code Detail Levels:** Usa `signatures` para planning, `full` para debugging
3. **RAG:** Encuentra código rápidamente sin memorizar la estructura

### Si lideras un equipo:
1. **Config compartida:** Commit `ai-first.config.json` en el repo
2. **Presets personalizados:** Define presets para cada tipo de tarea
3. **MCP Server:** Todos los devs usan el mismo contexto con el AI

### Si trabajas con microservicios:
1. **Multi-repo:** Contexto unificado de todos tus servicios
2. **Niveles de inclusión:** Comprime librerías compartidas
3. **RAG:** Busca funcionalidad que cruza servicios

---

## 🎓 Ejemplos Completos

### Ejemplo 1: "Refactorizar sistema de pagos"

```bash
# 1. Generar contexto enfocado en pagos
af init --preset api

# 2. Buscar todo lo relacionado con pagos
af query --semantic "payment processing stripe"

# 3. Ver quién trabajó en esto
af init --git-blame

# AI ahora puede ayudarte a refactorizar sabiendo:
# - Todo el código relevante (incluyendo dependencias)
# - Quién escribió qué (para preguntar dudas)
# - Estructura actual (para planear cambios)
```

### Ejemplo 2: "Onboarding de nuevo desarrollador"

```bash
# 1. Overview de la arquitectura
af init --detail-level skeleton

# 2. Documentación del proyecto
af init --preset docs

# 3. Código principal en modo signatures
af init --detail-level signatures

# Nuevo dev obtiene en 5 minutos:
# - Estructura del proyecto
# - Documentación existente
# - API del código (qué funciones existen)
# Sin verse abrumado por implementaciones
```

### Ejemplo 3: "Debugging en producción"

```bash
# 1. Contexto de últimos cambios
af init --git-blame

# 2. Buscar funciones relacionadas con el error
af query --semantic "error handling database connection"

# 3. Ver dependencias entre archivos
af map

# AI puede identificar:
# - Qué cambió recientemente que pudo causar el bug
# - Todas las funciones que manejan DB connections
# - Qué otros archivos dependen del código problemático
```

---

## 📚 Conclusión

Cada feature resuelve un problema específico en el flujo de trabajo con AI:

1. **Config/Presets** → Eliminan fricción y estandarizan
2. **Niveles de inclusión** → Reducen costos y mejoran precisión
3. **Git Blame** → Añaden contexto humano al código
4. **MCP Server** → Integración universal con AI agents
5. **RAG** → Hacen navegable cualquier codebase
6. **Multi-repo** → Escalan a arquitecturas empresariales

**El resultado:** Una herramienta que no solo "empaqueta código", sino que **entiende tu proyecto** y lo hace accesible para cualquier AI agent.

---

**Documento creado:** Marzo 2026  
**Próxima actualización:** Al completar FASE 2
