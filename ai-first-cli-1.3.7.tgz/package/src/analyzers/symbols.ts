import { FileInfo } from "../core/repoScanner.js";
import { readFile } from "../utils/fileUtils.js";
import { parserRegistry, createSymbolFromParsed } from "../core/parsers/index.js";

export interface Symbol {
  id: string;  // Unique ID: filePath#symbolName (e.g., src/auth/login.ts#loginUser)
  name: string;
  type: "function" | "class" | "interface" | "type" | "const" | "enum" | "module" | "export";
  file: string;
  line?: number;
  export?: boolean;
}

export interface SymbolsAnalysis {
  symbols: Symbol[];
  byId: Record<string, Symbol>;
  byFile: Record<string, Symbol[]>;
  byType: Record<string, Symbol[]>;
}

/**
 * Generate unique symbol ID from file path and symbol name
 * Format: filePath#symbolName (e.g., src/auth/login.ts#loginUser)
 */
export function generateSymbolId(filePath: string, symbolName: string): string {
  return `${filePath}#${symbolName}`;
}

/**
 * Extract symbols from source files
 */
export function extractSymbols(files: FileInfo[]): SymbolsAnalysis {
  const symbols: Symbol[] = [];
  const byFile: Record<string, Symbol[]> = {};

  for (const file of files) {
    const fileSymbols = parseFileForSymbols(file);
    symbols.push(...fileSymbols);
    
    if (fileSymbols.length > 0) {
      byFile[file.relativePath] = fileSymbols;
    }
  }

  // Build byId index
  const byId: Record<string, Symbol> = {};
  for (const sym of symbols) {
    byId[sym.id] = sym;
  }

  const byType: Record<string, Symbol[]> = {};
  for (const sym of symbols) {
    if (!byType[sym.type]) byType[sym.type] = [];
    byType[sym.type].push(sym);
  }

  return { symbols, byId, byFile, byType };
}

/**
 * Parse a single file for symbols
 */
function parseFileForSymbols(file: FileInfo): Symbol[] {
  const symbols: Symbol[] = [];

  try {
    const content = readFile(file.path);

    const ext = "." + file.extension;
    if (parserRegistry.hasParser(ext)) {
      const parsed = parserRegistry.parse(file.relativePath, content, ext);
      if (parsed) {
        return createSymbolFromParsed(parsed, file.relativePath);
      }
    }

    const lines = content.split("\n");
    if (file.extension === "go") {
      parseGo(file, content, lines, symbols);
    } else if (file.extension === "rs") {
      parseRust(file, content, lines, symbols);
    } else if (file.extension === "java") {
      parseJava(file, content, lines, symbols);
    } else if (file.extension === "cs") {
      parseCSharp(file, content, lines, symbols);
    } else if (file.extension === "cls" || file.extension === "trigger") {
      parseApex(file, content, lines, symbols);
    } else if (file.extension === "php") {
      parsePHP(file, content, lines, symbols);
    } else if (file.extension === "rb") {
      parseRuby(file, content, lines, symbols);
    } else if (file.extension === "swift") {
      parseSwift(file, content, lines, symbols);
    }
  } catch {}

  return symbols;
}

/**
 * Parse JavaScript/TypeScript files
 */
function parseJavaScriptTypeScript(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  const patterns = [
    { regex: /(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\(|(\w+)\s*:\s*(?:async\s+)?\()/, type: "function" as const },
    { regex: /(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/, type: "function" as const },
    { regex: /class\s+(\w+)/, type: "class" as const },
    { regex: /interface\s+(\w+)/, type: "interface" as const },
    { regex: /type\s+(\w+)/, type: "type" as const },
    { regex: /enum\s+(\w+)/, type: "enum" as const },
    { regex: /(?:export\s+)?(?:const|let)\s+(\w+)/, type: "const" as const },
    { regex: /export\s+module\s+(\w+)/, type: "module" as const },
  ];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    for (const p of patterns) {
      const match = line.match(p.regex);
      if (match) {
        const name = match[1] || match[2] || match[3];
        if (name && !name.startsWith("_") && name.length > 1) {
          symbols.push({
            id: generateSymbolId(file.relativePath, name),
            name,
            type: p.type,
            file: file.relativePath,
            line: i + 1,
            export: line.startsWith("export"),
          });
        }
      }
    }
  }
}

/**
 * Parse Python files
 */
function parsePython(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    const classMatch = line.match(/^class\s+(\w+)/);
    if (classMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, classMatch[1]),
        name: classMatch[1],
        type: "class",
        file: file.relativePath,
        line: i + 1,
        export: line.startsWith("class") && !line.startsWith("class _"),
      });
      continue;
    }

    const funcMatch = line.match(/^def\s+(\w+)/);
    if (funcMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, funcMatch[1]),
        name: funcMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: line.startsWith("def"),
      });
      continue;
    }

    const constMatch = line.match(/^([A-Z][A-Z0-9_]*)\s*=/);
    if (constMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, constMatch[1]),
        name: constMatch[1],
        type: "const",
        file: file.relativePath,
        line: i + 1,
      });
    }
  }
}

/**
 * Parse Go files
 */
function parseGo(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    const funcMatch = line.match(/^func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)/);
    if (funcMatch && funcMatch[1] !== "init") {
      symbols.push({
        id: generateSymbolId(file.relativePath, funcMatch[1]),
        name: funcMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: line.startsWith("func") && !line.startsWith("func (") && /func\s+[A-Z]/.test(line),
      });
    }

    const typeMatch = line.match(/^type\s+(\w+)/);
    if (typeMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, typeMatch[1]),
        name: typeMatch[1],
        type: "type",
        file: file.relativePath,
        line: i + 1,
      });
    }

    const constMatch = line.match(/^const\s+(?:\(\s*)?(\w+)/);
    if (constMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, constMatch[1]),
        name: constMatch[1],
        type: "const",
        file: file.relativePath,
        line: i + 1,
      });
    }
  }
}

/**
 * Parse Rust files
 */
function parseRust(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    const funcMatch = line.match(/^pub\s+fn\s+(\w+)/);
    if (funcMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, funcMatch[1]),
        name: funcMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: line.startsWith("pub"),
      });
    }

    const structMatch = line.match(/^pub\s+struct\s+(\w+)/);
    if (structMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, structMatch[1]),
        name: structMatch[1],
        type: "class",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    const enumMatch = line.match(/^pub\s+enum\s+(\w+)/);
    if (enumMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, enumMatch[1]),
        name: enumMatch[1],
        type: "enum",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    const constMatch = line.match(/^pub\s+const\s+(\w+)/);
    if (constMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, constMatch[1]),
        name: constMatch[1],
        type: "const",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }
  }
}

/**
 * Parse Java files
 */
function parseJava(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    const classMatch = line.match(/^(?:public\s+)?class\s+(\w+)/);
    if (classMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, classMatch[1]),
        name: classMatch[1],
        type: "class",
        file: file.relativePath,
        line: i + 1,
      });
    }

    const interfaceMatch = line.match(/^(?:public\s+)?interface\s+(\w+)/);
    if (interfaceMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, interfaceMatch[1]),
        name: interfaceMatch[1],
        type: "interface",
        file: file.relativePath,
        line: i + 1,
      });
    }

    const methodMatch = line.match(/^(?:public|private|protected)\s+(?:static\s+)?(?:\w+)\s+(\w+)\s*\(/);
    if (methodMatch && methodMatch[1] !== "if" && methodMatch[1] !== "for") {
      symbols.push({
        id: generateSymbolId(file.relativePath, methodMatch[1]),
        name: methodMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
      });
    }
  }
}

/**
 * Parse PHP files
 */
function parsePHP(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Classes: class ClassName, public class ClassName
    const classMatch = line.match(/^(?:public\s+|private\s+|protected\s+)?class\s+(\w+)/);
    if (classMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, classMatch[1]),
        name: classMatch[1],
        type: "class",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    // Interfaces: interface InterfaceName
    const interfaceMatch = line.match(/^(?:public\s+)?interface\s+(\w+)/);
    if (interfaceMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, interfaceMatch[1]),
        name: interfaceMatch[1],
        type: "interface",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    // Functions: function functionName
    const funcMatch = line.match(/^(?:public\s+|private\s+|protected\s+)?function\s+(\w+)/);
    if (funcMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, funcMatch[1]),
        name: funcMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    // Constants: const CONST_NAME
    const constMatch = line.match(/^const\s+(\w+)/);
    if (constMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, constMatch[1]),
        name: constMatch[1],
        type: "const",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }
  }
}

/**
 * Parse Ruby files
 */
function parseRuby(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Classes: class ClassName
    const classMatch = line.match(/^class\s+(\w+)/);
    if (classMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, classMatch[1]),
        name: classMatch[1],
        type: "class",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    // Modules: module ModuleName
    const moduleMatch = line.match(/^module\s+(\w+)/);
    if (moduleMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, moduleMatch[1]),
        name: moduleMatch[1],
        type: "module",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    const methodMatch = line.match(/^def\s+(\w+)/);
    if (methodMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, methodMatch[1]),
        name: methodMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    const classMethodMatch = line.match(/^def\s+self\.(\w+)/);
    if (classMethodMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, classMethodMatch[1]),
        name: classMethodMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }

    // Constants: CONST_NAME =
    const constMatch = line.match(/^([A-Z][A-Z0-9_]*)\s*=/);
    if (constMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, constMatch[1]),
        name: constMatch[1],
        type: "const",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }
  }
}

/**
 * Parse Swift files
 */
function parseSwift(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Classes/Structs: struct ViewName, class ClassName
    const structMatch = line.match(/^(?:struct|class)\s+(\w+)/);
    if (structMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, structMatch[1]),
        name: structMatch[1],
        type: "class",
        file: file.relativePath,
        line: i + 1,
        export: line.startsWith("struct") || line.startsWith("class"),
      });
    }
    
    // Functions: func functionName
    const funcMatch = line.match(/^func\s+(\w+)/);
    if (funcMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, funcMatch[1]),
        name: funcMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }
    
    // Enums: enum EnumName
    const enumMatch = line.match(/^enum\s+(\w+)/);
    if (enumMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, enumMatch[1]),
        name: enumMatch[1],
        type: "enum",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }
    
    // Protocols: protocol ProtocolName
    const protocolMatch = line.match(/^protocol\s+(\w+)/);
    if (protocolMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, protocolMatch[1]),
        name: protocolMatch[1],
        type: "interface",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }
    
    // Constants: let CONST_NAME or var CONST_NAME
    const constMatch = line.match(/^(?:let|var)\s+([A-Z][A-Z0-9_]*)/);
    if (constMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, constMatch[1]),
        name: constMatch[1],
        type: "const",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
    }
  }
}

/**
 * Parse Apex (Salesforce) files
 */
function parseApex(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  // Track annotations across lines
  let pendingAnnotations: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // Skip empty lines
    if (!line) {
      continue;
    }

    // Collect annotations (@AuraEnabled, @IsTest, etc.) - handles both single-line and multi-line
    // Match patterns like @AuraEnabled, @AuraEnabled(cacheable=true), @IsTest
    const annotationMatch = line.match(/^@(\w+)(?:\s*\([^)]*\))?\s*$/);
    if (annotationMatch) {
      pendingAnnotations.push(annotationMatch[1]);
      continue;
    }
    
    // Classes: public with sharing class ClassName, public class ClassName, etc.
    const classMatch = line.match(/^(?:\s*(?:public|private|global)(?:\s+(?:with|without|inherited)\s+sharing)?\s+)?class\s+(\w+)/);
    if (classMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, classMatch[1]),
        name: classMatch[1],
        type: "class",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
      pendingAnnotations = [];
      continue;
    }

    // Interfaces
    const interfaceMatch = line.match(/^(?:public\s+)?interface\s+(\w+)/);
    if (interfaceMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, interfaceMatch[1]),
        name: interfaceMatch[1],
        type: "interface",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
      pendingAnnotations = [];
      continue;
    }

    // Methods: public static ReturnType methodName(
    // Also handles @AuraEnabled public static ReturnType methodName(
    // Also handles @AuraEnabled(cacheable=true) on separate line
    // Handles generic return types like List<Account>, Map<String, Object>
    // Also handles webservice methods
    const methodMatch = line.match(/^(?:@\w+(?:\s*\([^)]*\))?\s+)?(?:public|private|protected|global|webservice)\s+(?:static\s+)?(?:[\w<>,\s]+?)\s+(\w+)\s*\(/);
    if (methodMatch && !["if", "for", "while", "switch"].includes(methodMatch[1])) {
      symbols.push({
        id: generateSymbolId(file.relativePath, methodMatch[1]),
        name: methodMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: line.includes("public") || line.includes("global") || line.includes("webservice"),
      });
      pendingAnnotations = [];
      continue;
    }

    // Alternative: Method with annotations on previous lines
    // Check if we have pending annotations and current line looks like a method
    if (pendingAnnotations.length > 0) {
      const methodWithAnnotationMatch = line.match(/^(?:public|private|protected|global|webservice)\s+(?:static\s+)?(?:[\w<>,\s]+?)\s+(\w+)\s*\(/);
      if (methodWithAnnotationMatch && !["if", "for", "while", "switch"].includes(methodWithAnnotationMatch[1])) {
        symbols.push({
          id: generateSymbolId(file.relativePath, methodWithAnnotationMatch[1]),
          name: methodWithAnnotationMatch[1],
          type: "function",
          file: file.relativePath,
          line: i + 1,
          export: line.includes("public") || line.includes("global") || line.includes("webservice"),
        });
        pendingAnnotations = [];
        continue;
      }
    }

    // Triggers: trigger TriggerName on ObjectName
    const triggerMatch = line.match(/^trigger\s+(\w+)\s+on\s+(\w+)/);
    if (triggerMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, triggerMatch[1]),
        name: triggerMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
        export: true,
      });
      pendingAnnotations = [];
      continue;
    }
    
    // Reset pending annotations if we encounter non-annotation, non-method line
    if (!line.startsWith("@")) {
      pendingAnnotations = [];
    }
  }
}

/**
 * Parse C# files
 */
function parseCSharp(file: FileInfo, content: string, lines: string[], symbols: Symbol[]): void {
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    const classMatch = line.match(/^(?:public\s+)?(?:partial\s+)?class\s+(\w+)/);
    if (classMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, classMatch[1]),
        name: classMatch[1],
        type: "class",
        file: file.relativePath,
        line: i + 1,
      });
    }

    const interfaceMatch = line.match(/^(?:public\s+)?interface\s+(\w+)/);
    if (interfaceMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, interfaceMatch[1]),
        name: interfaceMatch[1],
        type: "interface",
        file: file.relativePath,
        line: i + 1,
      });
    }

    const methodMatch = line.match(/^(?:public|private|protected|internal)\s+(?:static\s+)?(?:async\s+)?(?:\w+)\s+(\w+)\s*\(/);
    if (methodMatch) {
      symbols.push({
        id: generateSymbolId(file.relativePath, methodMatch[1]),
        name: methodMatch[1],
        type: "function",
        file: file.relativePath,
        line: i + 1,
      });
    }
  }
}

/**
 * Generate symbols.json with indexed symbols
 */
export function generateSymbolsJson(analysis: SymbolsAnalysis): string {
  // Build symbols index with new ID format
  const symbolsIndex: Record<string, any> = {};
  for (const sym of analysis.symbols) {
    symbolsIndex[sym.id] = {
      name: sym.name,
      type: sym.type,
      file: sym.file,
      line: sym.line,
      module: sym.file.split('/')[0],
      export: sym.export
    };
  }

  const output = {
    symbols: symbolsIndex,
    total: analysis.symbols.length,
    byType: analysis.byType,
    byFile: analysis.byFile,
    exported: analysis.symbols.filter(s => s.export),
  };
  return JSON.stringify(output, null, 2);
}
