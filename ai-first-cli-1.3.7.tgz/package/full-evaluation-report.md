# Evaluación Completa - 11 Proyectos

Fecha: 2026-03-28T23:12:14.067Z

## Resumen de Puntuaciones

| Proyecto | Prioridad | Score Local | Score AI | Estado |
|----------|-----------|-------------|----------|--------|
| salesforce-cli | high | 3.65 | - | ✅ |
| ai-first-cli | high | 3.75 | - | ✅ |
| express-api | medium | 3.88 | - | ✅ |
| nestjs-backend | medium | 3.77 | - | ✅ |
| python-cli | medium | 3.65 | - | ✅ |
| spring-boot-app | medium | 3.65 | - | ✅ |
| android-kotlin-app | low | 3.65 | - | ✅ |
| ios-swift-app | low | 3.65 | - | ✅ |
| go-microservice | low | 3.65 | - | ✅ |
| rust-cli | low | 3.65 | - | ✅ |
| php-vanilla | low | 3.65 | - | ✅ |

## Estadísticas

- **Score promedio:** 3.69/5.0
- **Proyectos con buena calidad (≥3.5):** 11/11
- **Proyectos que necesitan mejoras:** 0/11
- **Ahorro de costos:** 100%

## Top 10 Mejoras Recomendadas por las AIs

1. [HIGH] Replace generic phrases with specific functional descriptions of what each module does
2. [HIGH] Run "af init" to enable automatic freshness tracking for this project
3. [HIGH] Entry points should be documented with ### or #### headers
4. [HIGH] summary.md missing overview section
5. [HIGH] Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
6. [HIGH] API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects

## Mejoras por Proyecto

### salesforce-cli (Score: 3.65)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

### ai-first-cli (Score: 3.75)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

### express-api (Score: 3.88)

- Replace generic phrases with specific functional descriptions of what each module does
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers
- summary.md missing overview section
- summary.md missing purpose section

### nestjs-backend (Score: 3.77)

- Replace generic phrases with specific functional descriptions of what each module does
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers
- summary.md missing overview section

### python-cli (Score: 3.65)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

### spring-boot-app (Score: 3.65)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

### android-kotlin-app (Score: 3.65)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

### ios-swift-app (Score: 3.65)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

### go-microservice (Score: 3.65)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

### rust-cli (Score: 3.65)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

### php-vanilla (Score: 3.65)

- Replace generic phrases with specific functional descriptions of what each module does
- API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects
- Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI
- Run "af init" to enable automatic freshness tracking for this project
- Entry points should be documented with ### or #### headers

