# Guía de Migración a v1.4.0

> **Nota:** Esta guía te ayuda a migrar de v1.3.x a v1.4.0 con todas las nuevas mejoras arquitectónicas.

---

## 📦 Cambios Rápidos

### Actualización del paquete

```bash
npm install -g ai-first-cli@latest

# Verificar versión
af --version
# Debería mostrar: 1.4.0
```

---

## 🎛️ Nuevo Sistema de Configuración

### Opción 1: Usar Presets (Recomendado)

La forma más rápida de empezar:

```bash
# Análisis completo (comportamiento anterior)
af init --preset full

# Análisis rápido (solo código fuente)
af init --preset quick

# Enfocado en API
af init --preset api

# Solo documentación
af init --preset docs
```

### Opción 2: Archivo de Configuración

Crea `ai-first.config.json` en tu proyecto:

```json
{
  "version": "1.0",
  "preset": "quick",
  "analysis": {
    "detailLevel": "signatures",
    "inclusionLevel": "compress"
  },
  "output": {
    "directory": "ai-context",
    "formats": ["md", "json"]
  }
}
```

Ahora solo necesitas ejecutar:
```bash
af init
```

---

## 💻 Uso como Librería (Nuevo)

### Instalación como dependencia

```bash
npm install ai-first-cli
```

### Ejemplo básico

```typescript
import { loadConfig, runAIFirst, processContent } from 'ai-first-cli';

// Cargar configuración
const { config } = loadConfig({ preset: 'quick' });

// Generar contexto
const result = await runAIFirst({
  rootDir: './my-project',
  outputDir: './docs/context'
});

// Procesar contenido con compresión
const processed = processContent(sourceCode, {
  detailLevel: 'signatures',
  inclusionLevel: 'compress'
});

console.log(`Compresión: ${processed.compressionRatio.toFixed(1)}%`);
```

---

## 📦 Niveles de Compresión (Nuevo)

### Para reducir tokens significativamente

#### En línea de comandos:
```bash
# Solo firmas de funciones (reduce ~70% de tokens)
af init --detail-level signatures

# Solo estructura (imports/exports)
af init --detail-level skeleton

# Código completo (comportamiento anterior)
af init --detail-level full
```

#### En archivo de configuración:
```json
{
  "analysis": {
    "detailLevel": "signatures",
    "inclusionLevel": "compress"
  }
}
```

### Niveles de Inclusión de Archivos:

```json
{
  "files": {
    "include": ["src/**/*.ts"],           // Contenido completo
    "compress": ["lib/**/*.js"],          // Solo imports/signatures
    "directory": ["assets/**"],           // Solo en estructura
    "exclude": ["**/*.test.ts"]           // Excluir completamente
  }
}
```

---

## 🔌 Integración MCP (Nuevo)

### Para Cursor IDE

1. Crea `.cursor/mcp.json`:
```json
{
  "mcpServers": {
    "ai-first": {
      "command": "af",
      "args": ["mcp-server"]
    }
  }
}
```

2. Reinicia Cursor

3. Ahora puedes preguntar al AI:
   - "Generate context for the auth module"
   - "Find all functions that use the database"
   - "Show me the architecture of this project"

### Para Claude Code

1. Inicia el servidor MCP:
```bash
af mcp-server
```

2. Configura Claude Code para conectarse al servidor

---

## 🧠 Búsqueda Semántica (Nuevo)

### Uso básico

```typescript
import { createVectorIndex, semanticSearch } from 'ai-first-cli';

// Crear índice
const index = createVectorIndex('./ai-context/vectors.json');

// Indexar tu código
// (se hace automáticamente con af index --semantic)

// Buscar
const results = semanticSearch(index, "authentication flow", 5);
```

### En línea de comandos (próximamente):
```bash
af index --semantic
af query --semantic "user authentication"
```

---

## 🌐 Multi-Repositorio (Nuevo)

### Para monorepos

```bash
# Escanear múltiples repositorios
af init --repos ./frontend,./backend,./shared

# Incluir submódulos de git
af init --include-submodules
```

### Uso programático:

```typescript
import { scanMultiRepo } from 'ai-first-cli';

const context = scanMultiRepo({
  repositories: ['./frontend', './backend', './shared'],
  includeSubmodules: true
});
```

---

## 👤 Git Blame (Nuevo)

### En línea de comandos (próximamente):
```bash
af init --git-blame
```

### Uso programático:

```typescript
import { getGitBlame, formatGitBlame } from 'ai-first-cli';

const blame = getGitBlame('./my-project', 'src/utils.ts');
const formatted = formatGitBlame(blame, 'inline');

// Salida:
// [julianperezpesce 2025-03-28] function calculateTotal(items: Item[]): number {
// [julianperezpesce 2025-03-28]   return items.reduce((sum, item) => sum + item.price, 0);
// [julianperezpesce 2025-03-28] }
```

---

## 🔄 Cambios Breaking

### Antes (v1.3.x):
```bash
af init --include "src/**/*" --exclude "**/*.test.ts"
```

### Después (v1.4.0):
```bash
# Opción 1: Usar presets
af init --preset quick

# Opción 2: Configuración en archivo
# ai-first.config.json
{
  "files": {
    "include": ["src/**/*"],
    "exclude": ["**/*.test.ts"]
  }
}
# af init
```

---

## 📊 Comparativa: Antes vs Después

| Característica | v1.3.x | v1.4.0 |
|----------------|--------|--------|
| **Configuración** | Línea de comandos | Archivo JSON + Presets |
| **Tokens usados** | 100% | 30% (con compresión) |
| **Uso como librería** | ❌ No soportado | ✅ Full API |
| **Integración AI** | Manual | MCP Server nativo |
| **Búsqueda de código** | Grep | RAG Semántico |
| **Multi-repo** | Contextos separados | Unificado |

---

## 🆘 Solución de Problemas

### Error: "Cannot find module '@modelcontextprotocol/sdk'"

```bash
npm install -g ai-first-cli@latest
# El SDK de MCP se instala automáticamente
```

### Error: "Config file not found"

```bash
# La configuración es opcional, pero recomendada
# Crea ai-first.config.json o usa presets
af init --preset quick
```

### Error: "TypeScript compilation errors"

```bash
# Limpia build anterior
rm -rf dist/
npm run build
```

---

## 📚 Recursos Adicionales

- [CHANGELOG](./CHANGELOG.md) - Lista completa de cambios
- [FEATURES_GUIDE](./docs/planning/FEATURES_GUIDE.md) - Guía detallada de features
- [IMPLEMENTATION_PLAN](./docs/planning/IMPLEMENTATION_PLAN.md) - Plan técnico
- [README en Español](./README.es.md) - Documentación en español

---

## 🤝 Soporte

¿Tienes problemas con la migración?

1. [Abre un issue](https://github.com/julianperezpesce/ai-first/issues)
2. Revisa la [documentación completa](./docs/planning/FEATURES_GUIDE.md)
3. Consulta los [ejemplos](./docs/examples/)

---

**¡Disfruta de ai-first v1.4.0! 🚀**
