import { processContent, classifyFile } from '../src/core/content/contentProcessor.js';
import { CompressionStats } from '../src/core/content/types.js';
import fs from 'fs';
import path from 'path';

interface BenchmarkResult {
  filePath: string;
  originalSize: number;
  processedSize: number;
  compressionRatio: number;
  tokens: number;
  detailLevel: string;
}

export function runBenchmark(rootDir: string = './src'): CompressionStats {
  const files = findTypeScriptFiles(rootDir);
  const results: BenchmarkResult[] = [];
  
  let totalOriginal = 0;
  let totalProcessed = 0;
  let totalTokens = 0;
  
  console.log('Running compression benchmark...\n');
  
  for (const file of files.slice(0, 20)) {
    const content = fs.readFileSync(file, 'utf-8');
    const originalSize = content.length;
    
    // Test different detail levels
    const levels = ['full', 'signatures', 'skeleton'] as const;
    
    for (const detailLevel of levels) {
      const processed = processContent(content, {
        detailLevel,
        inclusionLevel: 'full',
        preserveComments: true,
        preserveImports: true
      });
      
      results.push({
        filePath: path.relative(rootDir, file),
        originalSize,
        processedSize: processed.processedLength,
        compressionRatio: processed.compressionRatio,
        tokens: processed.tokens,
        detailLevel
      });
      
      if (detailLevel === 'signatures') {
        totalOriginal += originalSize;
        totalProcessed += processed.processedLength;
        totalTokens += processed.tokens;
      }
    }
  }
  
  // Print results
  console.log('Benchmark Results:\n');
  console.log('File | Detail Level | Original | Processed | Ratio | Tokens');
  console.log('-'.repeat(80));
  
  for (const result of results.slice(0, 10)) {
    console.log(
      `${result.filePath.slice(0, 30).padEnd(30)} | ` +
      `${result.detailLevel.padEnd(12)} | ` +
      `${result.originalSize.toString().padStart(8)} | ` +
      `${result.processedSize.toString().padStart(9)} | ` +
      `${result.compressionRatio.toFixed(1).padStart(5)}% | ` +
      `${result.tokens.toString().padStart(6)}`
    );
  }
  
  const overallCompression = totalOriginal > 0 
    ? ((totalOriginal - totalProcessed) / totalOriginal) * 100 
    : 0;
  
  console.log('\n' + '='.repeat(80));
  console.log('Summary (signatures mode):');
  console.log(`  Total files: ${files.length}`);
  console.log(`  Original size: ${totalOriginal.toLocaleString()} chars`);
  console.log(`  Processed size: ${totalProcessed.toLocaleString()} chars`);
  console.log(`  Compression: ${overallCompression.toFixed(1)}%`);
  console.log(`  Estimated tokens: ${totalTokens.toLocaleString()}`);
  console.log(`  Token savings: ${(totalOriginal / 4 - totalTokens).toLocaleString()}`);
  
  return {
    totalFiles: files.length,
    fullFiles: 0,
    compressedFiles: files.length,
    directoryOnlyFiles: 0,
    excludedFiles: 0,
    originalTokens: totalOriginal / 4,
    processedTokens: totalTokens,
    savingsPercentage: overallCompression
  };
}

function findTypeScriptFiles(dir: string): string[] {
  const files: string[] = [];
  
  if (!fs.existsSync(dir)) {
    return files;
  }
  
  const entries = fs.readdirSync(dir);
  
  for (const entry of entries) {
    const fullPath = path.join(dir, entry);
    const stat = fs.statSync(fullPath);
    
    if (stat.isDirectory() && !entry.startsWith('.') && entry !== 'node_modules') {
      files.push(...findTypeScriptFiles(fullPath));
    } else if (stat.isFile() && entry.endsWith('.ts')) {
      files.push(fullPath);
    }
  }
  
  return files;
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runBenchmark('./src');
}
