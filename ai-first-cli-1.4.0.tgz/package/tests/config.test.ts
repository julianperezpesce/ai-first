import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'fs';
import path from 'path';
import { loadConfig, getPreset, listPresets } from '../src/config/configLoader.js';
import type { AIFirstConfig } from '../src/config/types.js';

describe('Config System', () => {
  const testDir = path.join(process.cwd(), 'test-config-temp');
  const configFile = path.join(testDir, 'ai-first.config.json');

  beforeEach(() => {
    if (!fs.existsSync(testDir)) {
      fs.mkdirSync(testDir, { recursive: true });
    }
  });

  afterEach(() => {
    if (fs.existsSync(testDir)) {
      fs.rmSync(testDir, { recursive: true, force: true });
    }
  });

  describe('loadConfig', () => {
    it('should load default config when no config file exists', () => {
      const result = loadConfig({ configPath: configFile });
      
      expect(result.config).toBeDefined();
      expect(result.source).toBe('default');
      expect(result.validation.valid).toBe(true);
    });

    it('should load config from file', () => {
      const config: AIFirstConfig = {
        version: '1.0',
        output: {
          directory: 'custom-context',
          formats: ['md'],
        },
      };
      
      fs.writeFileSync(configFile, JSON.stringify(config, null, 2));
      
      const result = loadConfig({ configPath: configFile });
      
      expect(result.source).toBe('file');
      expect(result.config.output?.directory).toBe('custom-context');
    });

    it('should apply preset from options', () => {
      const result = loadConfig({ 
        configPath: configFile,
        preset: 'quick' 
      });
      
      expect(result.source).toBe('preset');
      expect(result.config.preset).toBe('quick');
    });

    it('should apply overrides', () => {
      const result = loadConfig({
        configPath: configFile,
        overrides: {
          version: '1.0',
          output: {
            directory: 'override-context',
            formats: ['md'],
          },
        },
      });
      
      expect(result.config.output?.directory).toBe('override-context');
    });

    it('should handle invalid JSON gracefully', () => {
      fs.writeFileSync(configFile, 'invalid json');
      
      const result = loadConfig({ configPath: configFile });
      
      expect(result.validation.valid).toBe(false);
      expect(result.validation.errors.length).toBeGreaterThan(0);
    });

    it('should validate config and report errors', () => {
      const config = {
        version: '1.0',
        output: {
          directory: 'ai-context',
          formats: ['invalid-format'],
        },
      };
      
      fs.writeFileSync(configFile, JSON.stringify(config, null, 2));
      
      const result = loadConfig({ configPath: configFile });
      
      expect(result.validation.errors.length).toBeGreaterThan(0);
    });
  });

  describe('getPreset', () => {
    it('should return builtin presets', () => {
      const preset = getPreset('full');
      
      expect(preset).toBeDefined();
      expect(preset?.name).toBe('full');
    });

    it('should return undefined for non-existent preset', () => {
      const preset = getPreset('non-existent' as any);
      
      expect(preset).toBeUndefined();
    });
  });

  describe('listPresets', () => {
    it('should list all builtin presets', () => {
      const presets = listPresets();
      
      expect(presets.length).toBeGreaterThan(0);
      expect(presets.some(p => p.name === 'full')).toBe(true);
      expect(presets.some(p => p.name === 'quick')).toBe(true);
    });
  });

  describe('Config merging', () => {
    it('should merge nested config objects', () => {
      fs.writeFileSync(configFile, JSON.stringify({
        version: '1.0',
        output: {
          directory: 'custom',
          formats: ['md'],
          prettyPrint: false,
        },
      }, null, 2));
      
      const result = loadConfig({
        configPath: configFile,
        overrides: {
          version: '1.0',
          output: {
            directory: 'custom',
            formats: ['md'],
            prettyPrint: true,
          },
        },
      });
      
      expect(result.config.output?.directory).toBe('custom');
      expect(result.config.output?.prettyPrint).toBe(true);
    });
  });
});
