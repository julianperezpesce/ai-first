#!/usr/bin/env node
import { HierarchicalEvaluator } from './dist/core/evaluation/hierarchical-evaluator.js';
import { createRubricPrompt, parseRubricResponse } from './dist/core/evaluation/rubric-prompts.js';
import { synthesizeImprovements } from './dist/core/evaluation/llm-synthesizer.js';
import { readFileSync, existsSync, writeFileSync } from 'fs';
import { join } from 'path';

const PROJECTS = [
  { name: 'salesforce-cli', path: 'test-projects/salesforce-cli', priority: 'high' },
  { name: 'ai-first-cli', path: '.', priority: 'high' },
  { name: 'express-api', path: 'test-projects/express-api', priority: 'medium' },
  { name: 'nestjs-backend', path: 'test-projects/nestjs-backend', priority: 'medium' },
  { name: 'python-cli', path: 'test-projects/python-cli', priority: 'medium' },
  { name: 'spring-boot-app', path: 'test-projects/spring-boot-app', priority: 'medium' },
  { name: 'android-kotlin-app', path: 'test-projects/android-kotlin-app', priority: 'low' },
  { name: 'ios-swift-app', path: 'test-projects/ios-swift-app', priority: 'low' },
  { name: 'go-microservice', path: 'test-projects/go-microservice', priority: 'low' },
  { name: 'rust-cli', path: 'test-projects/rust-cli', priority: 'low' },
  { name: 'php-vanilla', path: 'test-projects/php-vanilla', priority: 'low' },
];

console.log('🚀 Evaluando los 11 proyectos de prueba\n');

const evaluator = new HierarchicalEvaluator(3.5);
const results = [];
let needsAICount = 0;

// Fase 1: Evaluación local (rápida, sin costos)
console.log('📊 FASE 1: Evaluación Local (sin costos)\n');
for (const project of PROJECTS) {
  const start = Date.now();
  const result = await evaluator.evaluateProject(project.path, project.name, true);
  const duration = Date.now() - start;
  
  results.push({ project, result });
  
  if (result.needsAIEvaluation) {
    needsAICount++;
    console.log(`⚠️  ${project.name}: ${result.normalizedScore.toFixed(2)}/5.0 [NECESITA AI]`);
  } else {
    console.log(`✅ ${project.name}: ${result.normalizedScore.toFixed(2)}/5.0 [AHORRO] ${duration}ms`);
  }
}

console.log(`\n📈 Resumen Fase 1:`);
console.log(`   - Total proyectos: ${results.length}`);
console.log(`   - Por encima de umbral (3.5): ${results.length - needsAICount} (ahorro de costos)`);
console.log(`   - Necesitan AI: ${needsAICount}`);
console.log(`   - Ahorro estimado: ${((results.length - needsAICount) / results.length * 100).toFixed(0)}%\n`);

// Fase 2: Evaluación AI solo para los que la necesitan
const apiKey = process.env.OPENCODE_API_KEY;
if (apiKey && needsAICount > 0) {
  console.log('🤖 FASE 2: Evaluación AI (solo proyectos por debajo del umbral)\n');
  
  for (const { project, result } of results.filter(r => r.result.needsAIEvaluation)) {
    console.log(`   Evaluando ${project.name} con AI...`);
    
    try {
      const aiContextPath = join(project.path, 'ai-context');
      const files = {};
      for (const file of ['summary.md', 'architecture.md', 'tech_stack.md']) {
        const fp = join(aiContextPath, file);
        if (existsSync(fp)) {
          files[file] = readFileSync(fp, 'utf8').substring(0, 2000);
        }
      }
      
      const prompt = createRubricPrompt(project.name, files);
      
      const response = await fetch('https://opencode.ai/zen/go/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: 'kimi-k2.5',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.3,
          max_tokens: 4000,
        }),
      });
      
      if (response.ok) {
        const data = await response.json();
        const content = data.choices?.[0]?.message?.content || '';
        const parsed = parseRubricResponse(content);
        
        if (parsed) {
          result.aiScore = parsed.normalizedScore;
          result.aiFeedback = parsed.feedback;
          result.aiImprovements = parsed.improvements;
          console.log(`      AI Score: ${parsed.normalizedScore.toFixed(2)}/5.0`);
        }
      }
    } catch (e) {
      console.log(`      ❌ Error: ${e.message}`);
    }
  }
} else if (needsAICount > 0) {
  console.log('⚠️  OPENCODE_API_KEY no configurada - saltando evaluación AI\n');
}

// Recopilar todas las mejoras
console.log('\n📋 RECOPILANDO MEJORAS SUGERIDAS\n');
const allImprovements = [];
for (const { project, result } of results) {
  const improvements = result.aiImprovements || result.synthesizedImprovements || [];
  if (improvements.length > 0) {
    allImprovements.push({
      project: project.name,
      score: result.aiScore || result.normalizedScore,
      improvements,
    });
  }
}

// Sintetizar todas las mejoras
const synthesisInputs = allImprovements.map(item => ({
  model: item.project,
  score: item.score,
  feedback: '',
  improvements: item.improvements,
}));

const synthesis = synthesizeImprovements(synthesisInputs, 10);

// Generar reporte
let report = '# Evaluación Completa - 11 Proyectos\n\n';
report += `Fecha: ${new Date().toISOString()}\n\n`;
report += '## Resumen de Puntuaciones\n\n';
report += '| Proyecto | Prioridad | Score Local | Score AI | Estado |\n';
report += '|----------|-----------|-------------|----------|--------|\n';

for (const { project, result } of results) {
  const localScore = result.normalizedScore.toFixed(2);
  const aiScore = result.aiScore ? result.aiScore.toFixed(2) : '-';
  const status = (result.aiScore || result.normalizedScore) >= 3.5 ? '✅' : '⚠️';
  report += `| ${project.name} | ${project.priority} | ${localScore} | ${aiScore} | ${status} |\n`;
}

report += '\n## Estadísticas\n\n';
const avgScore = results.reduce((sum, r) => sum + (r.result.aiScore || r.result.normalizedScore), 0) / results.length;
report += `- **Score promedio:** ${avgScore.toFixed(2)}/5.0\n`;
report += `- **Proyectos con buena calidad (≥3.5):** ${results.filter(r => (r.result.aiScore || r.result.normalizedScore) >= 3.5).length}/11\n`;
report += `- **Proyectos que necesitan mejoras:** ${results.filter(r => (r.result.aiScore || r.result.normalizedScore) < 3.5).length}/11\n`;
report += `- **Ahorro de costos:** ${((results.length - needsAICount) / results.length * 100).toFixed(0)}%\n\n`;

report += '## Top 10 Mejoras Recomendadas por las AIs\n\n';
for (let i = 0; i < synthesis.synthesizedImprovements.length; i++) {
  const rec = synthesis.prioritizedRecommendations[i];
  const impact = rec ? `[${rec.impact.toUpperCase()}]` : '';
  report += `${i + 1}. ${impact} ${synthesis.synthesizedImprovements[i]}\n`;
}

report += '\n## Mejoras por Proyecto\n\n';
for (const { project, improvements, score } of allImprovements) {
  if (improvements.length > 0) {
    report += `### ${project} (Score: ${score.toFixed(2)})\n\n`;
    for (const imp of improvements.slice(0, 5)) {
      report += `- ${imp}\n`;
    }
    report += '\n';
  }
}

// Mostrar en consola
console.log('='.repeat(70));
console.log(report);
console.log('='.repeat(70));

// Guardar reporte
writeFileSync('full-evaluation-report.md', report);
console.log('\n📝 Reporte guardado: full-evaluation-report.md');
