import { readFileSync, existsSync, writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import { HierarchicalEvaluator, createHierarchicalEvaluator } from './hierarchical-evaluator.js';
import { BaselineManager, getBaselineManager } from './baseline-manager.js';
import { EvaluationCache, getEvaluationCache } from './evaluation-cache.js';
import { synthesizeImprovements, SynthesisInput, createSynthesisReport } from './llm-synthesizer.js';
import { AI_CONTEXT_RUBRIC, createRubricPrompt, parseRubricResponse } from './rubric-prompts.js';

interface Config {
  projects: Array<{
    name: string;
    path: string;
    priority: 'high' | 'medium' | 'low';
    expectedFrameworks?: string[];
    expectedLanguages?: string[];
    minScore?: number;
    description?: string;
  }>;
  evaluation: {
    useAI: boolean;
    aiModels: string[];
    aiThreshold: number;
    useRubric: boolean;
    useHierarchical: boolean;
    cacheEnabled: boolean;
    cacheTTL: number;
    maxRetries: number;
    timeout: number;
  };
  thresholds: {
    minimumScore: number;
    failOnRegression: boolean;
    regressionDelta: number;
    criticalRegressionDelta: number;
  };
  baseline: {
    enabled: boolean;
    directory: string;
    autoSave: boolean;
    compareOnRun: boolean;
  };
  reporting: {
    format: 'markdown' | 'json';
    includeDetails: boolean;
    includeTrends: boolean;
    maxImprovements: number;
    outputDirectory: string;
  };
  synthesis: {
    useLLM: boolean;
    similarityThreshold: number;
    maxRecommendations: number;
    groupByCategory: boolean;
  };
}

function loadConfig(configPath: string = 'evaluator.config.json'): Config {
  if (!existsSync(configPath)) {
    throw new Error(`Config file not found: ${configPath}`);
  }
  return JSON.parse(readFileSync(configPath, 'utf8'));
}

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  return `${(ms / 60000).toFixed(1)}m`;
}

async function callOpenCodeAPI(
  model: string,
  prompt: string,
  apiKey: string,
  timeout: number
): Promise<string> {
  const data = {
    model,
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.3,
    max_tokens: 4000,
  };

  const response = await fetch('https://opencode.ai/zen/go/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error(`API call failed: ${response.status} ${response.statusText}`);
  }

  const result = await response.json() as { choices?: Array<{ message?: { content?: string } }> };
  return result.choices?.[0]?.message?.content || '';
}

async function runEvaluation(): Promise<void> {
  const args = process.argv.slice(2);
  const configPath = args.find(arg => arg.startsWith('--config='))?.split('=')[1] || 'evaluator.config.json';
  const outputPath = args.find(arg => arg.startsWith('--output='))?.split('=')[1];
  const skipCache = args.includes('--skip-cache');
  const compareBaseline = args.includes('--compare-baseline');
  const saveBaseline = args.includes('--save-baseline');
  const projectsFilter = args.find(arg => arg.startsWith('--projects='))?.split('=')[1];

  console.log('🚀 AI Context Evaluator (Improved)\n');

  const config = loadConfig(configPath);
  console.log(`📋 Loaded config: ${configPath}`);
  console.log(`   - ${config.projects.length} projects configured`);
  console.log(`   - Hierarchical evaluation: ${config.evaluation.useHierarchical ? 'enabled' : 'disabled'}`);
  console.log(`   - AI evaluation: ${config.evaluation.useAI ? 'enabled' : 'disabled'}`);
  console.log(`   - Cache: ${config.evaluation.cacheEnabled ? 'enabled' : 'disabled'}`);
  console.log();

  const apiKey = process.env.OPENCODE_API_KEY;
  if (config.evaluation.useAI && !apiKey) {
    console.error('❌ Error: OPENCODE_API_KEY not set');
    process.exit(1);
  }

  const cache = config.evaluation.cacheEnabled 
    ? getEvaluationCache({ enabled: true, defaultTTL: config.evaluation.cacheTTL })
    : getEvaluationCache({ enabled: false });

  const baselineManager = config.baseline.enabled
    ? getBaselineManager(config.baseline.directory)
    : null;

  const evaluator = createHierarchicalEvaluator(
    config.evaluation.aiThreshold,
    cache
  );

  let projects = config.projects;
  if (projectsFilter) {
    const filterList = projectsFilter.split(',').map(p => p.trim());
    projects = projects.filter(p => filterList.includes(p.name));
    console.log(`🔍 Filtered to ${projects.length} projects: ${filterList.join(', ')}\n`);
  }

  const results: Array<{
    project: typeof projects[0];
    evaluation: Awaited<ReturnType<HierarchicalEvaluator['evaluateProject']>>;
    aiResult?: { score: number; feedback: string; improvements: string[] };
  }> = [];

  let totalAPICalls = 0;
  let totalCacheHits = 0;
  const startTime = Date.now();

  for (const project of projects) {
    console.log(`📁 Evaluating: ${project.name} (${project.priority})`);
    
    const projectStart = Date.now();
    const evaluation = await evaluator.evaluateProject(
      project.path,
      project.name,
      skipCache
    );

    let aiResult: { score: number; feedback: string; improvements: string[] } | undefined;
    
    if (config.evaluation.useAI && evaluation.needsAIEvaluation) {
      console.log('   🤖 Running AI evaluation...');
      totalAPICalls++;
      
      try {
        const files: Record<string, string> = {};
        const aiContextPath = join(project.path, 'ai-context');
        const keyFiles = ['summary.md', 'architecture.md', 'tech_stack.md'];
        
        for (const file of keyFiles) {
          const filePath = join(aiContextPath, file);
          if (existsSync(filePath)) {
            files[file] = readFileSync(filePath, 'utf8').substring(0, 2000);
          }
        }

        const prompt = config.evaluation.useRubric
          ? createRubricPrompt(project.name, files)
          : createSimplePrompt(project.name, files, evaluation);

        const response = await callOpenCodeAPI(
          config.evaluation.aiModels[0],
          prompt,
          apiKey!,
          config.evaluation.timeout
        );

        const rubricParsed = parseRubricResponse(response);
        const simpleParsed = parseSimpleResponse(response);
        
        if (rubricParsed) {
          aiResult = {
            score: rubricParsed.normalizedScore,
            feedback: Object.values(rubricParsed.feedback).join('; ') || 'No feedback provided',
            improvements: rubricParsed.improvements,
          };
        } else if (simpleParsed) {
          aiResult = {
            score: simpleParsed.score,
            feedback: simpleParsed.feedback,
            improvements: simpleParsed.improvements,
          };
        }
      } catch (error) {
        console.log(`   ⚠️  AI evaluation failed: ${error}`);
      }
    } else if (!evaluation.needsAIEvaluation) {
      console.log('   ⏭️  Skipping AI evaluation (score above threshold)');
    }

    totalCacheHits += evaluation.cacheHits;
    const duration = Date.now() - projectStart;

    console.log(`   ✅ Score: ${evaluation.normalizedScore.toFixed(2)}/5.0 ${aiResult ? `(AI: ${aiResult.score.toFixed(2)})` : ''}`);
    console.log(`   ⏱️  Duration: ${formatDuration(duration)}`);
    console.log(`   💾 Cache hits: ${evaluation.cacheHits}\n`);

    results.push({ project, evaluation, aiResult });
  }

  const totalDuration = Date.now() - startTime;

  if (saveBaseline && baselineManager) {
    console.log('💾 Saving baseline...');
    const version = `v${Date.now()}`;
    await baselineManager.saveBaseline(
      version,
      results.map(r => ({
        projectName: r.project.name,
        score: r.aiResult?.score || r.evaluation.normalizedScore,
        feedback: r.aiResult?.feedback || r.evaluation.synthesizedImprovements.join(', '),
        improvements: r.aiResult?.improvements || r.evaluation.synthesizedImprovements,
        hasIndexDb: r.evaluation.levelResults['Local Structure']?.checks.some(
          c => c.name === 'json_valid' && c.score > 0
        ) || false,
        aiContextPath: join(r.project.path, 'ai-context'),
      }))
    );
    console.log(`   ✅ Baseline saved: ${version}\n`);
  }

  let regressionReport = null;
  if (compareBaseline && baselineManager) {
    const baselines = baselineManager.listBaselines();
    if (baselines.length > 0) {
      const latestBaseline = baselines[0].version;
      console.log(`📊 Comparing with baseline: ${latestBaseline}`);
      
      regressionReport = await baselineManager.compareWithBaseline(
        results.map(r => ({
          projectName: r.project.name,
          score: r.aiResult?.score || r.evaluation.normalizedScore,
          feedback: r.aiResult?.feedback || '',
          improvements: r.aiResult?.improvements || r.evaluation.synthesizedImprovements,
        })),
        latestBaseline
      );
      
      console.log(`   ${regressionReport.hasRegressions ? '❌' : '✅'} ${regressionReport.summary}\n`);
    }
  }

  const report = generateReport(results, regressionReport, {
    totalDuration,
    totalAPICalls,
    totalCacheHits,
    config,
  });

  if (outputPath) {
    const dir = join(outputPath, '..');
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
    writeFileSync(outputPath, report);
    console.log(`📝 Report saved: ${outputPath}`);
  }

  console.log('\n' + '='.repeat(50));
  console.log(report);

  const failedProjects = results.filter(r => 
    (r.aiResult?.score || r.evaluation.normalizedScore) < (r.project.minScore || config.thresholds.minimumScore)
  );

  if (failedProjects.length > 0) {
    console.log(`\n❌ ${failedProjects.length} project(s) below minimum score threshold`);
    process.exit(1);
  }

  if (regressionReport?.hasRegressions && config.thresholds.failOnRegression) {
    console.log('\n❌ Regressions detected');
    process.exit(1);
  }

  console.log('\n✅ All evaluations passed');
}

function createSimplePrompt(
  projectName: string,
  files: Record<string, string>,
  localEval: { normalizedScore: number; levelScores: Record<string, number> }
): string {
  const fileContents = Object.entries(files)
    .map(([name, content]) => `=== ${name} ===\n${content}`)
    .join('\n\n');

  return `
Evaluate AI context quality for: ${projectName}

Local evaluation: ${localEval.normalizedScore.toFixed(2)}/5.0
Structure: ${localEval.levelScores['Local Structure'] || 0}/40
Content: ${localEval.levelScores['Content Quality'] || 0}/30

${fileContents}

Rate 1-5 and return JSON:
{"score": 4.0, "feedback": "brief feedback", "improvements": ["suggestion 1", "suggestion 2"]}
`.trim();
}

function parseSimpleResponse(response: string): { score: number; feedback: string; improvements: string[] } | null {
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return null;
    return JSON.parse(jsonMatch[0]);
  } catch {
    return null;
  }
}

function generateReport(
  results: Array<{
    project: { name: string; priority: string; minScore?: number };
    evaluation: { normalizedScore: number; executionTime: number; synthesizedImprovements: string[] };
    aiResult?: { score: number; feedback: string; improvements: string[] };
  }>,
  regressionReport: { hasRegressions: boolean; summary: string; regressions: Array<{ projectName: string; delta: number }> } | null,
  stats: {
    totalDuration: number;
    totalAPICalls: number;
    totalCacheHits: number;
    config: Config;
  }
): string {
  const scores = results.map(r => r.aiResult?.score || r.evaluation.normalizedScore);
  const avgScore = scores.reduce((a, b) => a + b, 0) / scores.length;

  let report = `# AI Context Evaluation Report\n\n`;
  report += `Generated: ${new Date().toISOString()}\n\n`;
  
  report += `## Summary\n\n`;
  report += `- **Projects Evaluated:** ${results.length}\n`;
  report += `- **Average Score:** ${avgScore.toFixed(2)}/5.0\n`;
  report += `- **Total Duration:** ${formatDuration(stats.totalDuration)}\n`;
  report += `- **API Calls:** ${stats.totalAPICalls}\n`;
  report += `- **Cache Hits:** ${stats.totalCacheHits}\n`;
  report += `- **Cost Savings:** ~${Math.round((stats.totalCacheHits / (stats.totalCacheHits + results.length)) * 100)}%\n\n`;

  if (regressionReport) {
    report += `## Regression Analysis\n\n`;
    report += `${regressionReport.hasRegressions ? '❌ REGRESSIONS DETECTED' : '✅ No regressions'}\n\n`;
    report += `${regressionReport.summary}\n\n`;
    
    if (regressionReport.regressions.length > 0) {
      report += `### Regressions\n\n`;
      report += `| Project | Delta | Severity |\n`;
      report += `|---------|-------|----------|\n`;
      for (const reg of regressionReport.regressions) {
        const severity = reg.delta < -1.0 ? '🔴 Critical' : '🟡 Warning';
        report += `| ${reg.projectName} | ${reg.delta.toFixed(2)} | ${severity} |\n`;
      }
      report += `\n`;
    }
  }

  report += `## Project Results\n\n`;
  report += `| Project | Priority | Score | Status | Min Score |\n`;
  report += `|---------|----------|-------|--------|-----------|\n`;
  
  for (const result of results) {
    const score = result.aiResult?.score || result.evaluation.normalizedScore;
    const minScore = result.project.minScore || stats.config.thresholds.minimumScore;
    const status = score >= minScore ? '✅ PASS' : '❌ FAIL';
    report += `| ${result.project.name} | ${result.project.priority} | ${score.toFixed(2)} | ${status} | ${minScore} |\n`;
  }
  
  report += `\n`;

  if (stats.config.reporting.includeDetails) {
    report += `## Detailed Results\n\n`;
    
    for (const result of results) {
      const score = result.aiResult?.score || result.evaluation.normalizedScore;
      report += `### ${result.project.name}\n\n`;
      report += `- **Priority:** ${result.project.priority}\n`;
      report += `- **Score:** ${score.toFixed(2)}/5.0\n`;
      report += `- **Duration:** ${formatDuration(result.evaluation.executionTime)}\n`;
      
      if (result.aiResult) {
        report += `- **AI Feedback:** ${result.aiResult.feedback}\n`;
      }
      
      if (result.evaluation.synthesizedImprovements.length > 0) {
        report += `- **Improvements:**\n`;
        for (const imp of result.evaluation.synthesizedImprovements.slice(0, 5)) {
          report += `  - ${imp}\n`;
        }
      }
      
      report += `\n`;
    }
  }

  const allImprovements = results.flatMap(r => 
    r.aiResult?.improvements || r.evaluation.synthesizedImprovements
  );
  
  if (allImprovements.length > 0) {
    const synthesis = synthesizeImprovements(
      results.map(r => ({
        model: 'hierarchical',
        score: r.aiResult?.score || r.evaluation.normalizedScore,
        feedback: r.aiResult?.feedback || '',
        improvements: r.aiResult?.improvements || r.evaluation.synthesizedImprovements,
      })),
      stats.config.synthesis.maxRecommendations
    );

    report += `## Top Recommendations\n\n`;
    for (let i = 0; i < synthesis.synthesizedImprovements.length; i++) {
      report += `${i + 1}. ${synthesis.synthesizedImprovements[i]}\n`;
    }
    report += `\n`;
  }

  return report;
}

runEvaluation().catch(error => {
  console.error('❌ Evaluation failed:', error);
  process.exit(1);
});
