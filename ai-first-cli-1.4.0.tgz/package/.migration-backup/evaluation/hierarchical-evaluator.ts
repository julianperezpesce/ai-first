import { readFileSync, existsSync, readdirSync } from 'fs';
import { join, extname } from 'path';
import { EvaluationCache, EvaluationResult } from './evaluation-cache.js';
import { BaselineManager, RegressionReport } from './baseline-manager.js';

// Framework detection utilities for conditional scoring
const SUPPORTED_FRAMEWORKS = [
  'django', 'rails', 'laravel', 'express', 'nestjs', 
  'spring', 'fastapi', 'flask'
];

// Check result extended to indicate if check was skipped
interface CheckResultExtended extends CheckResult {
  skipped?: boolean;
}

const API_FRAMEWORKS = [
  'express', 'fastify', 'nest', 'nestjs', 'spring', 
  'fastapi', 'django', 'flask', 'laravel'
];

function detectFrameworkFromFiles(projectPath: string): string | null {
  const techStackPath = join(projectPath, 'tech_stack.md');
  if (!existsSync(techStackPath)) return null;

  try {
    const content = readFileSync(techStackPath, 'utf8').toLowerCase();

    // Check for supported frameworks - order matters for specificity
    if (content.includes('spring boot')) return 'spring';
    if (content.includes('express')) return 'express';
    if (content.includes('nestjs') || content.includes('@nestjs')) return 'nestjs';
    if (content.includes('fastapi')) return 'fastapi';
    if (content.includes('django')) return 'django';
    if (content.includes('flask')) return 'flask';
    if (content.includes('rails')) return 'rails';
    if (content.includes('laravel')) return 'laravel';
    if (content.includes('spring')) return 'spring'; // Fallback for Spring without Boot

    return null;
  } catch {
    return null;
  }
}

function isAPIProject(projectPath: string): boolean {
  const framework = detectFrameworkFromFiles(projectPath);
  if (framework && API_FRAMEWORKS.includes(framework)) return true;
  
  // Check for API patterns in summary
  const summaryPath = join(projectPath, 'summary.md');
  if (existsSync(summaryPath)) {
    try {
      const content = readFileSync(summaryPath, 'utf8').toLowerCase();
      return content.includes('api') || content.includes('rest') || content.includes('server');
    } catch {
      return false;
    }
  }
  
  return false;
}

function hasIndexState(aiContextPath: string): boolean {
  const indexStatePath = join(aiContextPath, '..', 'index-state.json');
  return existsSync(indexStatePath);
}

function isFrameworkSupported(projectPath: string): boolean {
  const framework = detectFrameworkFromFiles(projectPath);
  return framework !== null && SUPPORTED_FRAMEWORKS.includes(framework);
}

export interface Check {
  name: string;
  validator: (filePath: string, content: string) => CheckResult;
  maxScore: number;
}

export interface CheckResult {
  passed: boolean;
  score: number;
  feedback: string;
  suggestions: string[];
  skipped?: boolean;
  metadata?: {
    category?: 'IMPLEMENTED' | 'USER_ACTION' | 'KNOWN_LIMITATION' | 'IMPROVEMENT' | 'INFO';
    severity?: 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
  };
}

export interface EvaluationLevel {
  name: string;
  maxScore: number;
  checks: Check[];
  useAI?: boolean;
}

export interface CategorizedSuggestion {
  text: string;
  category: 'IMPLEMENTED' | 'USER_ACTION' | 'KNOWN_LIMITATION' | 'IMPROVEMENT' | 'INFO';
  severity: 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
}

export interface HierarchicalEvaluation {
  projectName: string;
  projectPath: string;
  levelScores: Record<string, number>;
  totalScore: number;
  maxPossibleScore: number;
  normalizedScore: number;
  levelResults: Record<string, LevelResult>;
  needsAIEvaluation: boolean;
  aiScore?: number;
  synthesizedImprovements: string[];
  categorizedSuggestions?: CategorizedSuggestion[];
  executionTime: number;
  cacheHits: number;
  cacheMisses: number;
}

export interface LevelResult {
  score: number;
  maxScore: number;
  checks: Array<{
    name: string;
    score: number;
    maxScore: number;
    feedback: string;
  }>;
}

const LOCAL_STRUCTURE_CHECKS: Check[] = [
  {
    name: 'files_exist',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResult => {
      const requiredFiles = ['summary.md', 'architecture.md', 'tech_stack.md'];
      const existingFiles = readdirSync(filePath).map(f => f.toLowerCase());
      const missingFiles = requiredFiles.filter(f => !existingFiles.includes(f));
      
      if (missingFiles.length === 0) {
        return {
          passed: true,
          score: 10,
          feedback: 'All required files present',
          suggestions: [],
        };
      }
      
      return {
        passed: false,
        score: Math.max(0, 10 - missingFiles.length * 3),
        feedback: `Missing files: ${missingFiles.join(', ')}`,
        suggestions: missingFiles.map(f => `Create ${f} file`),
      };
    },
  },
  {
    name: 'json_valid',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResult => {
      const jsonFiles = ['symbols.json', 'dependencies.json', 'repo_map.json'];
      let validCount = 0;
      let invalidFiles: string[] = [];
      
      for (const jsonFile of jsonFiles) {
        const fullPath = join(filePath, jsonFile);
        if (existsSync(fullPath)) {
          try {
            const jsonContent = readFileSync(fullPath, 'utf8');
            JSON.parse(jsonContent);
            validCount++;
          } catch {
            invalidFiles.push(jsonFile);
          }
        }
      }
      
      if (invalidFiles.length === 0 && validCount > 0) {
        return {
          passed: true,
          score: 10,
          feedback: `All ${validCount} JSON files are valid`,
          suggestions: [],
        };
      }
      
      return {
        passed: false,
        score: Math.max(0, validCount * 3),
        feedback: invalidFiles.length > 0 
          ? `Invalid JSON files: ${invalidFiles.join(', ')}` 
          : 'No JSON files found',
        suggestions: invalidFiles.map(f => `Fix JSON syntax in ${f}`),
      };
    },
  },
  {
    name: 'markdown_format',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResult => {
      const mdFiles = ['summary.md', 'architecture.md', 'tech_stack.md', 'ai_context.md'];
      let validCount = 0;
      let issues: string[] = [];
      
      for (const mdFile of mdFiles) {
        const fullPath = join(filePath, mdFile);
        if (existsSync(fullPath)) {
          try {
            const mdContent = readFileSync(fullPath, 'utf8');
            
            if (mdContent.length < 50) {
              issues.push(`${mdFile} is too short`);
            } else if (!mdContent.includes('#')) {
              issues.push(`${mdFile} missing headers`);
            } else {
              validCount++;
            }
          } catch {
            issues.push(`${mdFile} unreadable`);
          }
        }
      }
      
      return {
        passed: validCount >= 3,
        score: Math.min(10, validCount * 3),
        feedback: validCount >= 3 
          ? 'Markdown files well-formatted' 
          : `Issues found: ${issues.join(', ')}`,
        suggestions: issues,
      };
    },
  },
  {
    name: 'cross_references',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResult => {
      try {
        const repoMapPath = join(filePath, 'repo_map.json');
        if (!existsSync(repoMapPath)) {
          return {
            passed: false,
            score: 0,
            feedback: 'No repo_map.json for cross-reference validation',
            suggestions: ['Generate repo_map.json'],
          };
        }
        
        const repoMap = JSON.parse(readFileSync(repoMapPath, 'utf8'));
        const hasValidStructure = repoMap && 
          (repoMap.modules || repoMap.files || repoMap.structure);
        
        if (hasValidStructure) {
          return {
            passed: true,
            score: 10,
            feedback: 'Cross-references validated via repo_map.json',
            suggestions: [],
          };
        }
        
        return {
          passed: false,
          score: 5,
          feedback: 'repo_map.json exists but has incomplete structure',
          suggestions: ['Regenerate repo_map.json with full structure'],
        };
      } catch {
        return {
          passed: false,
          score: 0,
          feedback: 'Error validating cross-references',
          suggestions: ['Check repo_map.json validity'],
        };
      }
    },
  },
];

const CONTENT_QUALITY_CHECKS: Check[] = [
  {
    name: 'descriptions_meaningful',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResult => {
      try {
        const summaryPath = join(filePath, 'summary.md');
        if (!existsSync(summaryPath)) {
          return {
            passed: false,
            score: 0,
            feedback: 'No summary.md for description check',
            suggestions: ['Create summary.md with project description'],
          };
        }
        
        const summary = readFileSync(summaryPath, 'utf8');
        const genericPhrases = [
          'contains',
          'files',
          'this is a',
          'project with',
        ];
        
        const hasGeneric = genericPhrases.some(phrase => 
          summary.toLowerCase().includes(phrase)
        );
        
        if (!hasGeneric && summary.length > 200) {
          return {
            passed: true,
            score: 10,
            feedback: 'Descriptions are specific and meaningful',
            suggestions: [],
          };
        }
        
        return {
          passed: false,
          score: hasGeneric ? 3 : 7,
          feedback: hasGeneric
            ? 'Descriptions contain generic phrases'
            : 'Descriptions too brief',
          suggestions: hasGeneric
            ? ['Replace generic phrases with specific functional descriptions of what each module does']
            : ['Expand descriptions to include business context and functionality'],
          metadata: {
            category: 'IMPROVEMENT',
            severity: 'HIGH'
          }
        };
      } catch {
        return {
          passed: false,
          score: 0,
          feedback: 'Error checking descriptions',
          suggestions: [],
        };
      }
    },
  },
  {
    name: 'no_generic_phrases',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResult => {
      const genericPatterns = [
        /contains \d+ files/i,
        /this project (is|has)/i,
        /a (simple|basic) (app|application|project)/i,
      ];
      
      let issues: string[] = [];
      const mdFiles = ['summary.md', 'architecture.md'];
      
      for (const mdFile of mdFiles) {
        const fullPath = join(filePath, mdFile);
        if (existsSync(fullPath)) {
          const mdContent = readFileSync(fullPath, 'utf8');
          for (const pattern of genericPatterns) {
            if (pattern.test(mdContent)) {
              issues.push(`Generic phrase in ${mdFile}`);
              break;
            }
          }
        }
      }
      
      if (issues.length === 0) {
        return {
          passed: true,
          score: 10,
          feedback: 'No generic phrases detected',
          suggestions: [],
        };
      }
      
      return {
        passed: false,
        score: Math.max(0, 10 - issues.length * 3),
        feedback: `Generic phrases found: ${issues.join(', ')}`,
        suggestions: ['Replace "Contains X files" with functional descriptions'],
      };
    },
  },
  {
    name: 'consistent_formatting',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResult => {
      const mdFiles = ['summary.md', 'architecture.md', 'tech_stack.md'];
      let consistentCount = 0;
      let inconsistencies: string[] = [];
      
      let firstHasToc = false;
      let firstHeaderStyle: string | null = null;
      
      for (let i = 0; i < mdFiles.length; i++) {
        const fullPath = join(filePath, mdFiles[i]);
        if (existsSync(fullPath)) {
          const mdContent = readFileSync(fullPath, 'utf8');
          const hasToc = mdContent.toLowerCase().includes('table of contents') || 
                        mdContent.includes('## ');
          const usesHashHeaders = mdContent.startsWith('#');
          
          if (i === 0) {
            firstHasToc = hasToc;
            firstHeaderStyle = usesHashHeaders ? 'hash' : 'other';
            consistentCount++;
          } else {
            if (hasToc === firstHasToc) {
              consistentCount++;
            } else {
              inconsistencies.push(`${mdFiles[i]} TOC mismatch`);
            }
          }
        }
      }
      
      return {
        passed: consistentCount >= 2,
        score: Math.min(10, consistentCount * 3),
        feedback: consistentCount >= 2 
          ? 'Formatting consistent across files' 
          : `Inconsistencies: ${inconsistencies.join(', ')}`,
        suggestions: inconsistencies,
      };
    },
  },
  {
    name: 'api_contracts_present',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResultExtended => {
      const apiContractsPath = join(filePath, 'api-contracts.md');

      if (!existsSync(apiContractsPath)) {
        return {
          passed: true,
          score: 0,
          feedback: 'No API contracts file - check skipped',
          suggestions: ['API contracts feature is available but only applies to Express/NestJS/Spring/FastAPI/Django projects'],
          skipped: true,
          metadata: {
            category: 'IMPLEMENTED',
            severity: 'INFO'
          }
        };
      }

      const contractsContent = readFileSync(apiContractsPath, 'utf8');
      const endpointMatches = contractsContent.match(/#### (GET|POST|PUT|DELETE|PATCH)/g);
      const endpointCount = endpointMatches ? endpointMatches.length : 0;

      if (endpointCount > 0) {
        return {
          passed: true,
          score: 10,
          feedback: `API contracts documented with ${endpointCount} endpoints`,
          suggestions: [],
        };
      }

      return {
        passed: true,
        score: 5,
        feedback: 'API contracts file present but no endpoints detected',
        suggestions: ['Verify API routes are being detected correctly'],
        metadata: {
          category: 'IMPROVEMENT',
          severity: 'MEDIUM'
        }
      };
    },
  },
  {
    name: 'framework_instructions_present',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResultExtended => {
      const instructionsPath = join(filePath, 'instructions.md');

      if (!existsSync(instructionsPath)) {
        return {
          passed: true,
          score: 0,
          feedback: 'No framework instructions file - check skipped',
          suggestions: ['Framework instructions feature is available for Django, Rails, Laravel, Express, NestJS, Spring, FastAPI'],
          skipped: true,
          metadata: {
            category: 'IMPLEMENTED',
            severity: 'INFO'
          }
        };
      }

      const instructionsContent = readFileSync(instructionsPath, 'utf8');
      const hasHowToSection = instructionsContent.includes('## How To');
      const hasCommonTasks = instructionsContent.includes('## Common Tasks');

      if (hasHowToSection && hasCommonTasks) {
        return {
          passed: true,
          score: 10,
          feedback: 'Framework-specific instructions present with How To and Common Tasks',
          suggestions: [],
        };
      }

      return {
        passed: true,
        score: 7,
        feedback: 'Framework instructions present but incomplete',
        suggestions: ['Add missing How To or Common Tasks sections'],
        metadata: {
          category: 'IMPROVEMENT',
          severity: 'LOW'
        }
      };
    },
  },
  {
    name: 'context_freshness',
    maxScore: 10,
    validator: (filePath: string, content: string): CheckResultExtended => {
      const indexStatePath = join(filePath, '..', 'index-state.json');

      if (!existsSync(indexStatePath)) {
        return {
          passed: true,
          score: 0,
          feedback: 'No index state - freshness check skipped',
          suggestions: ['Run "af init" to enable automatic freshness tracking for this project'],
          skipped: true,
          metadata: {
            category: 'USER_ACTION',
            severity: 'INFO'
          }
        };
      }

      try {
        const indexState = JSON.parse(readFileSync(indexStatePath, 'utf8'));
        const lastIndexed = new Date(indexState.lastIndexed);
        const daysSinceIndexed = Math.floor((Date.now() - lastIndexed.getTime()) / (1000 * 60 * 60 * 24));

        if (daysSinceIndexed < 7) {
          return {
            passed: true,
            score: 10,
            feedback: `Context indexed ${daysSinceIndexed} days ago (fresh)`,
            suggestions: [],
          };
        } else if (daysSinceIndexed < 30) {
          return {
            passed: true,
            score: 7,
            feedback: `Context indexed ${daysSinceIndexed} days ago (moderately fresh)`,
            suggestions: ['Context is getting old. Consider running "af init" to refresh'],
            metadata: {
              category: 'USER_ACTION',
              severity: 'LOW'
            }
          };
        } else {
          return {
            passed: false,
            score: 3,
            feedback: `Context indexed ${daysSinceIndexed} days ago (stale)`,
            suggestions: ['Context is stale. Run "af init" to refresh with latest changes'],
            metadata: {
              category: 'USER_ACTION',
              severity: 'MEDIUM'
            }
          };
        }
      } catch {
        return {
          passed: false,
          score: 0,
          feedback: 'Error reading index state',
          suggestions: ['Index state file may be corrupted. Run "af init" to regenerate'],
          metadata: {
            category: 'USER_ACTION',
            severity: 'HIGH'
          }
        };
      }
    },
  },
  {
    name: 'entrypoint_documentation',
    maxScore: 15,
    validator: (filePath: string): CheckResultExtended => {
      const entrypointsPath = join(filePath, 'entrypoints.md');

      if (!existsSync(entrypointsPath)) {
        return {
          passed: false,
          score: 0,
          feedback: 'No entrypoints.md found',
          suggestions: ['Run "af init" to generate entrypoints documentation'],
          metadata: {
            category: 'USER_ACTION',
            severity: 'HIGH'
          }
        };
      }

      try {
        const content = readFileSync(entrypointsPath, 'utf8');
        const lines = content.split('\n');

        // Count entry points (lines starting with ### or ####)
        const entryPoints = lines.filter(line =>
          line.startsWith('### ') || line.startsWith('#### ')
        );

        if (entryPoints.length === 0) {
          return {
            passed: false,
            score: 3,
            feedback: 'Entry points file exists but no entry points detected',
            suggestions: ['Entry points should be documented with ### or #### headers'],
            metadata: {
              category: 'IMPROVEMENT',
              severity: 'MEDIUM'
            }
          };
        }

        // Check for descriptions (content after entry point headers)
        let documentedCount = 0;
        for (let i = 0; i < lines.length; i++) {
          if (lines[i].startsWith('### ') || lines[i].startsWith('#### ')) {
            // Check next few lines for description
            let hasDescription = false;
            for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
              if (lines[j].trim().length > 10 && !lines[j].startsWith('#')) {
                hasDescription = true;
                break;
              }
            }
            if (hasDescription) documentedCount++;
          }
        }

        const documentationRatio = documentedCount / entryPoints.length;

        if (documentationRatio >= 0.8) {
          return {
            passed: true,
            score: 15,
            feedback: `All ${entryPoints.length} entry points well documented with descriptions`,
            suggestions: []
          };
        } else if (documentationRatio >= 0.5) {
          return {
            passed: true,
            score: 10,
            feedback: `${documentedCount}/${entryPoints.length} entry points have descriptions`,
            suggestions: [`Add descriptions to ${entryPoints.length - documentedCount} remaining entry points`],
            metadata: {
              category: 'IMPROVEMENT',
              severity: 'LOW'
            }
          };
        } else {
          return {
            passed: false,
            score: 5,
            feedback: `Only ${documentedCount}/${entryPoints.length} entry points have descriptions`,
            suggestions: ['Add purpose descriptions for each entry point', 'Document parameters and dependencies'],
            metadata: {
              category: 'IMPROVEMENT',
              severity: 'HIGH'
            }
          };
        }
      } catch {
        return {
          passed: false,
          score: 0,
          feedback: 'Error reading entrypoints file',
          suggestions: ['Verify entrypoints.md is readable'],
          metadata: {
            category: 'KNOWN_LIMITATION',
            severity: 'LOW'
          }
        };
      }
    },
  },
  {
    name: 'documentation_completeness',
    maxScore: 15,
    validator: (filePath: string): CheckResultExtended => {
      const requiredFiles = [
        { name: 'summary.md', requiredSections: ['overview', 'purpose', 'features'] },
        { name: 'architecture.md', requiredSections: ['pattern', 'components', 'structure'] },
        { name: 'tech_stack.md', requiredSections: ['languages', 'frameworks'] }
      ];

      let totalScore = 0;
      const issues: string[] = [];

      for (const file of requiredFiles) {
        const fullFilePath = join(filePath, file.name);
        if (!existsSync(fullFilePath)) {
          issues.push(`${file.name} is missing`);
          continue;
        }

        try {
          const content = readFileSync(fullFilePath, 'utf8').toLowerCase();
          let fileScore = 0;

          for (const section of file.requiredSections) {
            if (content.includes(section) || content.includes(`## ${section}`)) {
              fileScore += 1;
            } else {
              issues.push(`${file.name} missing ${section} section`);
            }
          }

          totalScore += (fileScore / file.requiredSections.length) * 5;
        } catch {
          issues.push(`Error reading ${file.name}`);
        }
      }

      const finalScore = Math.min(15, Math.round(totalScore));

      if (finalScore >= 12) {
        return {
          passed: true,
          score: finalScore,
          feedback: 'Documentation is comprehensive with all required sections',
          suggestions: []
        };
      } else if (finalScore >= 8) {
        return {
          passed: true,
          score: finalScore,
          feedback: 'Documentation is mostly complete but missing some sections',
          suggestions: issues.slice(0, 3),
          metadata: {
            category: 'IMPROVEMENT',
            severity: 'MEDIUM'
          }
        };
      } else {
        return {
          passed: false,
          score: finalScore,
          feedback: 'Documentation is incomplete',
          suggestions: issues.slice(0, 5).length > 0 ? issues.slice(0, 5) : ['Add missing required sections to documentation files'],
          metadata: {
            category: 'IMPROVEMENT',
            severity: 'HIGH'
          }
        };
      }
    },
  },
];

export const EVALUATION_LEVELS: EvaluationLevel[] = [
  {
    name: 'Local Structure',
    maxScore: 40,
    checks: LOCAL_STRUCTURE_CHECKS,
  },
  {
    name: 'Content Quality',
    maxScore: 80,
    checks: CONTENT_QUALITY_CHECKS,
  },
  {
    name: 'AI Assessment',
    maxScore: 10,
    checks: [],
    useAI: true,
  },
];

export class HierarchicalEvaluator {
  private cache: EvaluationCache;
  private baselineManager: BaselineManager;
  private aiThreshold: number;

  constructor(
    aiThreshold: number = 3.5,
    cache?: EvaluationCache,
    baselineManager?: BaselineManager
  ) {
    this.aiThreshold = aiThreshold;
    this.cache = cache || new EvaluationCache();
    this.baselineManager = baselineManager || new BaselineManager();
  }

  async evaluateProject(
    projectPath: string,
    projectName: string,
    skipCache: boolean = false
  ): Promise<HierarchicalEvaluation> {
    const startTime = Date.now();
    const aiContextPath = join(projectPath, 'ai-context');
    
    if (!existsSync(aiContextPath)) {
      return {
        projectName,
        projectPath,
        levelScores: {},
        totalScore: 0,
        maxPossibleScore: 100,
        normalizedScore: 0,
        levelResults: {},
        needsAIEvaluation: true,
        synthesizedImprovements: ['No ai-context directory found - run af init first'],
        executionTime: 0,
        cacheHits: 0,
        cacheMisses: 0,
      };
    }

    let cacheHits = 0;
    let cacheMisses = 0;
    const levelScores: Record<string, number> = {};
    const levelResults: Record<string, LevelResult> = {};
    let totalScore = 0;
    let maxPossibleScore = 0;
    let allSuggestions: string[] = [];
    const categorizedSuggestions: CategorizedSuggestion[] = [];

    for (const level of EVALUATION_LEVELS) {
      if (level.useAI) {
        continue;
      }

      let levelScore = 0;
      const checkResults: LevelResult['checks'] = [];

      let levelMaxScore = 0;

      for (const check of level.checks) {
        const cacheKey = `${projectName}:${level.name}:${check.name}`;
        
        let result: CheckResultExtended;
        let fromCache = false;
        
        if (!skipCache) {
          const cached = this.cache.getCachedEvaluation(cacheKey);
          if (cached) {
            result = {
              passed: cached.score > check.maxScore * 0.6,
              score: cached.score,
              feedback: cached.feedback,
              suggestions: cached.improvements,
              skipped: cached.skipped,
            };
            fromCache = true;
            cacheHits++;
          } else {
            result = check.validator(aiContextPath, '') as CheckResultExtended;
            cacheMisses++;
          }
        } else {
          result = check.validator(aiContextPath, '') as CheckResultExtended;
          cacheMisses++;
        }

        if (!fromCache) {
          this.cache.setEvaluation(cacheKey, {
            score: result.score,
            feedback: result.feedback,
            improvements: result.suggestions,
            skipped: result.skipped,
          }, projectName);
        }

        levelScore += result.score;

        if (!result.skipped) {
          levelMaxScore += check.maxScore;
        }

        checkResults.push({
          name: check.name,
          score: result.score,
          maxScore: check.maxScore,
          feedback: result.feedback,
        });

        allSuggestions.push(...result.suggestions);

        // Collect categorized suggestions
        if (result.suggestions.length > 0) {
          result.suggestions.forEach(suggestion => {
            categorizedSuggestions.push({
              text: suggestion,
              category: result.metadata?.category || 'IMPROVEMENT',
              severity: result.metadata?.severity || 'MEDIUM'
            });
          });
        }
      }

      levelScores[level.name] = levelScore;
      levelResults[level.name] = {
        score: levelScore,
        maxScore: levelMaxScore,
        checks: checkResults,
      };

      totalScore += levelScore;
      maxPossibleScore += levelMaxScore;
    }

    const normalizedScore = maxPossibleScore > 0 
      ? (totalScore / maxPossibleScore) * 100 
      : 0;

    const needsAIEvaluation = normalizedScore < this.aiThreshold * 20;

    const uniqueSuggestions = [...new Set(allSuggestions)].slice(0, 10);

    return {
      projectName,
      projectPath,
      levelScores,
      totalScore,
      maxPossibleScore,
      normalizedScore: normalizedScore / 20,
      levelResults,
      needsAIEvaluation,
      synthesizedImprovements: uniqueSuggestions,
      categorizedSuggestions: categorizedSuggestions.slice(0, 10),
      executionTime: Date.now() - startTime,
      cacheHits,
      cacheMisses,
    };
  }

  async evaluateWithAI(
    projectPath: string,
    projectName: string,
    aiEvaluator: (prompt: string) => Promise<EvaluationResult>
  ): Promise<HierarchicalEvaluation> {
    const localEval = await this.evaluateProject(projectPath, projectName);
    
    if (!localEval.needsAIEvaluation) {
      return localEval;
    }

    const aiContextPath = join(projectPath, 'ai-context');
    const prompt = this.createAIPrompt(aiContextPath, projectName, localEval);
    
    const aiResult = await aiEvaluator(prompt);
    
    return {
      ...localEval,
      aiScore: aiResult.score,
      totalScore: localEval.totalScore + (aiResult.score * 6),
      normalizedScore: Math.min(5, (localEval.normalizedScore + aiResult.score) / 2),
      synthesizedImprovements: [
        ...localEval.synthesizedImprovements,
        ...aiResult.improvements,
      ].slice(0, 10),
    };
  }

  private createAIPrompt(
    aiContextPath: string,
    projectName: string,
    localEval: HierarchicalEvaluation
  ): string {
    const files: Record<string, string> = {};
    const keyFiles = ['summary.md', 'architecture.md', 'tech_stack.md'];
    
    for (const file of keyFiles) {
      const filePath = join(aiContextPath, file);
      if (existsSync(filePath)) {
        files[file] = readFileSync(filePath, 'utf8').substring(0, 3000);
      }
    }

    return `
Evaluate AI context quality for project: ${projectName}

Local evaluation completed:
- Structure Score: ${localEval.levelScores['Local Structure'] || 0}/40
- Content Score: ${localEval.levelScores['Content Quality'] || 0}/30

FILES TO EVALUATE:
${Object.entries(files).map(([name, content]) => `
=== ${name} ===
${content}`).join('\n')}

Rate from 1-5 on:
1. AI USEFULNESS - Can an AI use this to understand the codebase?
2. ACCURACY - Is the technical information correct?
3. ACTIONABILITY - Can AI generate code based on this context?

Return JSON format:
{"score": 4.0, "feedback": "good but needs X", "improvements": ["improvement 1", "improvement 2"]}
`.trim();
  }

  async compareWithBaseline(
    currentEval: HierarchicalEvaluation,
    baselineVersion: string
  ): Promise<RegressionReport> {
    return this.baselineManager.compareWithBaseline(
      [{
        projectName: currentEval.projectName,
        score: currentEval.normalizedScore,
        feedback: currentEval.synthesizedImprovements.join(', '),
        improvements: currentEval.synthesizedImprovements,
      }],
      baselineVersion
    );
  }

  getCacheStats(): ReturnType<EvaluationCache['getStats']> {
    return this.cache.getStats();
  }
}

export function createHierarchicalEvaluator(
  aiThreshold?: number,
  cache?: EvaluationCache,
  baselineManager?: BaselineManager
): HierarchicalEvaluator {
  return new HierarchicalEvaluator(aiThreshold, cache, baselineManager);
}
