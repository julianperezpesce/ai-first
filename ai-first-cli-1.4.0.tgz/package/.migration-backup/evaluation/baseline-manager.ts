import { readFileSync, existsSync, writeFileSync, mkdirSync, readdirSync } from 'fs';
import { join, dirname } from 'path';

export interface Baseline {
  version: string;
  timestamp: string;
  scores: Record<string, number>;
  metrics: {
    avgScore: number;
    testPassRate: number;
    coverage: number;
    totalProjects: number;
  };
  projectDetails: Record<string, ProjectBaseline>;
}

export interface ProjectBaseline {
  projectName: string;
  score: number;
  feedback: string;
  improvements: string[];
  hasIndexDb: boolean;
  fileHashes: Record<string, string>;
}

export interface Regression {
  projectName: string;
  metric: string;
  previousValue: number;
  currentValue: number;
  delta: number;
  severity: 'critical' | 'warning' | 'info';
}

export interface RegressionReport {
  hasRegressions: boolean;
  regressions: Regression[];
  improvements: Regression[];
  unchanged: string[];
  summary: string;
}

export interface TrendReport {
  timeRange: string;
  baselines: Baseline[];
  trends: {
    avgScoreTrend: 'up' | 'down' | 'stable';
    passRateTrend: 'up' | 'down' | 'stable';
    scoreDelta: number;
  };
}

const DEFAULT_BASELINE_DIR = '.sisyphus/baselines';

export class BaselineManager {
  private baselineDir: string;

  constructor(baselineDir: string = DEFAULT_BASELINE_DIR) {
    this.baselineDir = baselineDir;
    this.ensureDirectoryExists();
  }

  private ensureDirectoryExists(): void {
    if (!existsSync(this.baselineDir)) {
      mkdirSync(this.baselineDir, { recursive: true });
    }
  }

  private getBaselinePath(version: string): string {
    return join(this.baselineDir, `baseline-${version}.json`);
  }

  private calculateFileHash(filePath: string): string | null {
    try {
      const content = readFileSync(filePath, 'utf8');
      let hash = 0;
      for (let i = 0; i < content.length; i++) {
        const char = content.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
      }
      return hash.toString(16);
    } catch {
      return null;
    }
  }

  async saveBaseline(
    version: string,
    evaluations: Array<{
      projectName: string;
      score: number;
      feedback: string;
      improvements: string[];
      hasIndexDb: boolean;
      aiContextPath: string;
    }>
  ): Promise<Baseline> {
    const scores: Record<string, number> = {};
    const projectDetails: Record<string, ProjectBaseline> = {};
    let totalScore = 0;
    let validScores = 0;

    for (const eval_ of evaluations) {
      scores[eval_.projectName] = eval_.score;
      
      if (eval_.score > 0) {
        totalScore += eval_.score;
        validScores++;
      }

      const fileHashes: Record<string, string> = {};
      const aiContextPath = eval_.aiContextPath;
      
      if (existsSync(aiContextPath)) {
        const keyFiles = [
          'summary.md',
          'architecture.md',
          'tech_stack.md',
          'entrypoints.md',
          'ai_context.md',
        ];
        
        for (const file of keyFiles) {
          const filePath = join(aiContextPath, file);
          if (existsSync(filePath)) {
            const hash = this.calculateFileHash(filePath);
            if (hash) {
              fileHashes[file] = hash;
            }
          }
        }
      }

      projectDetails[eval_.projectName] = {
        projectName: eval_.projectName,
        score: eval_.score,
        feedback: eval_.feedback,
        improvements: eval_.improvements,
        hasIndexDb: eval_.hasIndexDb,
        fileHashes,
      };
    }

    const avgScore = validScores > 0 ? totalScore / validScores : 0;
    const passingProjects = evaluations.filter(e => e.score >= 3.0).length;
    const testPassRate = evaluations.length > 0 
      ? (passingProjects / evaluations.length) * 100 
      : 0;

    const baseline: Baseline = {
      version,
      timestamp: new Date().toISOString(),
      scores,
      metrics: {
        avgScore,
        testPassRate,
        coverage: 0,
        totalProjects: evaluations.length,
      },
      projectDetails,
    };

    const baselinePath = this.getBaselinePath(version);
    writeFileSync(baselinePath, JSON.stringify(baseline, null, 2));

    return baseline;
  }

  async loadBaseline(version: string): Promise<Baseline | null> {
    const baselinePath = this.getBaselinePath(version);
    
    if (!existsSync(baselinePath)) {
      return null;
    }

    try {
      const content = readFileSync(baselinePath, 'utf8');
      return JSON.parse(content) as Baseline;
    } catch {
      return null;
    }
  }

  async compareWithBaseline(
    currentEvaluations: Array<{
      projectName: string;
      score: number;
      feedback: string;
      improvements: string[];
    }>,
    baselineVersion: string
  ): Promise<RegressionReport> {
    const baseline = await this.loadBaseline(baselineVersion);
    
    if (!baseline) {
      return {
        hasRegressions: false,
        regressions: [],
        improvements: [],
        unchanged: [],
        summary: `No baseline found for version ${baselineVersion}`,
      };
    }

    const regressions: Regression[] = [];
    const improvements: Regression[] = [];
    const unchanged: string[] = [];

    for (const current of currentEvaluations) {
      const baselineScore = baseline.scores[current.projectName];
      
      if (baselineScore === undefined) {
        continue;
      }

      const delta = current.score - baselineScore;
      const deltaPercent = baselineScore > 0 ? (delta / baselineScore) * 100 : 0;

      if (delta < -0.5) {
        regressions.push({
          projectName: current.projectName,
          metric: 'overall_score',
          previousValue: baselineScore,
          currentValue: current.score,
          delta,
          severity: delta < -1.0 ? 'critical' : 'warning',
        });
      } else if (delta > 0.5) {
        improvements.push({
          projectName: current.projectName,
          metric: 'overall_score',
          previousValue: baselineScore,
          currentValue: current.score,
          delta,
          severity: 'info',
        });
      } else {
        unchanged.push(current.projectName);
      }
    }

    const hasRegressions = regressions.length > 0;
    const summary = this.generateRegressionSummary(
      regressions,
      improvements,
      unchanged
    );

    return {
      hasRegressions,
      regressions,
      improvements,
      unchanged,
      summary,
    };
  }

  async detectRegressions(
    currentVersion: string,
    previousVersion: string
  ): Promise<Regression[]> {
    const current = await this.loadBaseline(currentVersion);
    const previous = await this.loadBaseline(previousVersion);

    if (!current || !previous) {
      return [];
    }

    const regressions: Regression[] = [];

    for (const [projectName, currentScore] of Object.entries(current.scores)) {
      const previousScore = previous.scores[projectName];
      
      if (previousScore === undefined) {
        continue;
      }

      const delta = currentScore - previousScore;

      if (delta < -0.5) {
        regressions.push({
          projectName,
          metric: 'overall_score',
          previousValue: previousScore,
          currentValue: currentScore,
          delta,
          severity: delta < -1.0 ? 'critical' : 'warning',
        });
      }
    }

    return regressions;
  }

  generateTrendReport(timeRange: string): TrendReport {
    const baselineFiles = readdirSync(this.baselineDir)
      .filter(f => f.startsWith('baseline-') && f.endsWith('.json'))
      .sort();

    const baselines: Baseline[] = [];
    
    for (const file of baselineFiles) {
      try {
        const content = readFileSync(join(this.baselineDir, file), 'utf8');
        const baseline = JSON.parse(content) as Baseline;
        baselines.push(baseline);
      } catch {
        // Skip invalid baseline files
      }
    }

    if (baselines.length < 2) {
      return {
        timeRange,
        baselines,
        trends: {
          avgScoreTrend: 'stable',
          passRateTrend: 'stable',
          scoreDelta: 0,
        },
      };
    }

    const first = baselines[0];
    const last = baselines[baselines.length - 1];
    const scoreDelta = last.metrics.avgScore - first.metrics.avgScore;

    let avgScoreTrend: 'up' | 'down' | 'stable' = 'stable';
    if (scoreDelta > 0.3) {
      avgScoreTrend = 'up';
    } else if (scoreDelta < -0.3) {
      avgScoreTrend = 'down';
    }

    let passRateTrend: 'up' | 'down' | 'stable' = 'stable';
    const passRateDelta = last.metrics.testPassRate - first.metrics.testPassRate;
    if (passRateDelta > 5) {
      passRateTrend = 'up';
    } else if (passRateDelta < -5) {
      passRateTrend = 'down';
    }

    return {
      timeRange,
      baselines,
      trends: {
        avgScoreTrend,
        passRateTrend,
        scoreDelta,
      },
    };
  }

  listBaselines(): Array<{ version: string; timestamp: string; avgScore: number }> {
    if (!existsSync(this.baselineDir)) {
      return [];
    }

    const baselineFiles = readdirSync(this.baselineDir)
      .filter(f => f.startsWith('baseline-') && f.endsWith('.json'));

    const baselines: Array<{ version: string; timestamp: string; avgScore: number }> = [];

    for (const file of baselineFiles) {
      try {
        const content = readFileSync(join(this.baselineDir, file), 'utf8');
        const baseline = JSON.parse(content) as Baseline;
        baselines.push({
          version: baseline.version,
          timestamp: baseline.timestamp,
          avgScore: baseline.metrics.avgScore,
        });
      } catch {
        // Skip invalid baseline files
      }
    }

    return baselines.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  private generateRegressionSummary(
    regressions: Regression[],
    improvements: Regression[],
    unchanged: string[]
  ): string {
    const parts: string[] = [];

    if (regressions.length > 0) {
      const criticalCount = regressions.filter(r => r.severity === 'critical').length;
      parts.push(`${regressions.length} regression(s) detected${criticalCount > 0 ? ` (${criticalCount} critical)` : ''}`);
    }

    if (improvements.length > 0) {
      parts.push(`${improvements.length} improvement(s)`);
    }

    if (unchanged.length > 0) {
      parts.push(`${unchanged.length} unchanged`);
    }

    if (parts.length === 0) {
      return 'No changes detected';
    }

    return parts.join(', ');
  }
}

export function getBaselineManager(baselineDir?: string): BaselineManager {
  return new BaselineManager(baselineDir);
}
