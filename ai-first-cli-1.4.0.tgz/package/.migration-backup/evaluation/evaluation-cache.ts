/**
 * evaluation-cache.ts
 *
 * Intelligent caching system for AI context evaluations.
 * Only re-evaluates files that have changed based on content hash.
 */

import { createHash } from 'crypto';
import { readFileSync, existsSync, writeFileSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';

/**
 * Cache entry structure
 */
export interface CacheEntry {
  filePath: string;
  fileHash: string;
  timestamp: number;
  evaluation: EvaluationResult;
  ttl: number;
  projectName: string;
}

/**
 * Evaluation result structure
 */
export interface EvaluationResult {
  score: number;
  feedback: string;
  improvements: string[];
  metadata?: Record<string, unknown>;
  skipped?: boolean;
}

/**
 * Cache configuration
 */
export interface CacheConfig {
  cacheDir: string;
  defaultTTL: number;
  enabled: boolean;
}

/**
 * Default cache configuration
 */
const DEFAULT_CONFIG: CacheConfig = {
  cacheDir: '.sisyphus/cache/evaluations',
  defaultTTL: 24 * 60 * 60 * 1000, // 24 hours
  enabled: true,
};

/**
 * Evaluation Cache Manager
 *
 * Provides intelligent caching to avoid re-evaluating unchanged files.
 * Uses MD5 hash of file content to detect changes.
 */
export class EvaluationCache {
  private cache: Map<string, CacheEntry> = new Map();
  private config: CacheConfig;
  private cacheFilePath: string;

  constructor(config: Partial<CacheConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.cacheFilePath = join(this.config.cacheDir, 'evaluation-cache.json');
    this.loadCache();
  }

  /**
   * Calculate MD5 hash of a file's content
   */
  private calculateFileHash(filePath: string): string | null {
    try {
      const content = readFileSync(filePath, 'utf8');
      return createHash('md5').update(content).digest('hex');
    } catch {
      return null;
    }
  }

  /**
   * Check if a file needs to be re-evaluated
   */
  shouldReevaluate(filePath: string): boolean {
    if (!this.config.enabled) {
      return true;
    }

    const cached = this.cache.get(filePath);
    if (!cached) {
      return true;
    }

    // Check TTL
    if (Date.now() - cached.timestamp > cached.ttl) {
      return true;
    }

    // Check if file content changed
    const currentHash = this.calculateFileHash(filePath);
    if (!currentHash || currentHash !== cached.fileHash) {
      return true;
    }

    return false;
  }

  /**
   * Get cached evaluation result for a file
   */
  getCachedEvaluation(filePath: string): EvaluationResult | null {
    const cached = this.cache.get(filePath);
    if (!cached) {
      return null;
    }

    // Verify the cache is still valid
    if (this.shouldReevaluate(filePath)) {
      return null;
    }

    return cached.evaluation;
  }

  /**
   * Store evaluation result in cache
   */
  setEvaluation(
    filePath: string,
    evaluation: EvaluationResult,
    projectName: string,
    ttl?: number
  ): void {
    if (!this.config.enabled) {
      return;
    }

    const fileHash = this.calculateFileHash(filePath);
    if (!fileHash) {
      return;
    }

    const entry: CacheEntry = {
      filePath,
      fileHash,
      timestamp: Date.now(),
      evaluation,
      ttl: ttl ?? this.config.defaultTTL,
      projectName,
    };

    this.cache.set(filePath, entry);
    this.saveCache();
  }

  /**
   * Get cache statistics
   */
  getStats(): {
    totalEntries: number;
    projects: string[];
    oldestEntry: number | null;
    newestEntry: number | null;
  } {
    const entries = Array.from(this.cache.values());
    const timestamps = entries.map((e) => e.timestamp);

    return {
      totalEntries: entries.length,
      projects: [...new Set(entries.map((e) => e.projectName))],
      oldestEntry: timestamps.length > 0 ? Math.min(...timestamps) : null,
      newestEntry: timestamps.length > 0 ? Math.max(...timestamps) : null,
    };
  }

  /**
   * Invalidate cache entries for a specific project
   */
  invalidateProject(projectName: string): number {
    let count = 0;
    for (const [key, entry] of this.cache.entries()) {
      if (entry.projectName === projectName) {
        this.cache.delete(key);
        count++;
      }
    }
    if (count > 0) {
      this.saveCache();
    }
    return count;
  }

  /**
   * Clear all cache entries
   */
  clear(): void {
    this.cache.clear();
    this.saveCache();
  }

  /**
   * Clean up expired cache entries
   */
  cleanup(): number {
    const now = Date.now();
    let count = 0;

    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key);
        count++;
      }
    }

    if (count > 0) {
      this.saveCache();
    }

    return count;
  }

  /**
   * Load cache from disk
   */
  private loadCache(): void {
    if (!existsSync(this.cacheFilePath)) {
      return;
    }

    try {
      const data = readFileSync(this.cacheFilePath, 'utf8');
      const parsed = JSON.parse(data) as Record<string, CacheEntry>;

      // Convert back to Map
      this.cache = new Map(Object.entries(parsed));

      // Clean up expired entries on load
      this.cleanup();
    } catch (error) {
      console.warn('Failed to load evaluation cache:', error);
      this.cache = new Map();
    }
  }

  /**
   * Save cache to disk
   */
  private saveCache(): void {
    try {
      // Ensure directory exists
      const dir = dirname(this.cacheFilePath);
      if (!existsSync(dir)) {
        mkdirSync(dir, { recursive: true });
      }

      // Convert Map to object for JSON serialization
      const data = Object.fromEntries(this.cache.entries());
      writeFileSync(this.cacheFilePath, JSON.stringify(data, null, 2));
    } catch (error) {
      console.warn('Failed to save evaluation cache:', error);
    }
  }
}

/**
 * Create a singleton cache instance
 */
let globalCache: EvaluationCache | null = null;

export function getEvaluationCache(config?: Partial<CacheConfig>): EvaluationCache {
  if (!globalCache) {
    globalCache = new EvaluationCache(config);
  }
  return globalCache;
}

export function resetEvaluationCache(): void {
  globalCache = null;
}
