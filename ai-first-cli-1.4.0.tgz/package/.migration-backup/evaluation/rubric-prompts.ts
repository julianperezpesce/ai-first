export interface RubricCriterion {
  name: string;
  maxPoints: number;
  description: string;
  checkpoints: Array<{
    description: string;
    points: number;
  }>;
}

export interface RubricSection {
  name: string;
  maxPoints: number;
  criteria: RubricCriterion[];
}

export interface RubricEvaluation {
  sectionScores: Record<string, number>;
  criterionScores: Record<string, number>;
  totalScore: number;
  maxPossibleScore: number;
  normalizedScore: number;
  feedback: Record<string, string>;
  improvements: string[];
}

export const AI_CONTEXT_RUBRIC: RubricSection[] = [
  {
    name: 'File Presence',
    maxPoints: 20,
    criteria: [
      {
        name: 'summary',
        maxPoints: 5,
        description: 'summary.md exists with adequate content',
        checkpoints: [
          { description: 'File exists', points: 2 },
          { description: 'Content > 100 characters', points: 1 },
          { description: 'Contains project description', points: 1 },
          { description: 'Has clear purpose statement', points: 1 },
        ],
      },
      {
        name: 'architecture',
        maxPoints: 5,
        description: 'architecture.md with detected patterns',
        checkpoints: [
          { description: 'File exists', points: 2 },
          { description: 'Identifies architectural pattern', points: 2 },
          { description: 'Shows component relationships', points: 1 },
        ],
      },
      {
        name: 'tech_stack',
        maxPoints: 5,
        description: 'tech_stack.md with framework detection',
        checkpoints: [
          { description: 'File exists', points: 2 },
          { description: 'Lists detected frameworks', points: 2 },
          { description: 'Shows version information', points: 1 },
        ],
      },
      {
        name: 'entrypoints',
        maxPoints: 5,
        description: 'entrypoints.md with real entry points',
        checkpoints: [
          { description: 'File exists', points: 2 },
          { description: 'Lists actual entry points', points: 2 },
          { description: 'Describes entry point purpose', points: 1 },
        ],
      },
    ],
  },
  {
    name: 'Content Quality',
    maxPoints: 30,
    criteria: [
      {
        name: 'descriptions',
        maxPoints: 10,
        description: 'Functional descriptions, not generic',
        checkpoints: [
          { description: 'No "Contains X files" phrases', points: 4 },
          { description: 'Describes functionality', points: 3 },
          { description: 'Business context provided', points: 3 },
        ],
      },
      {
        name: 'specificity',
        maxPoints: 10,
        description: 'Specific technical details',
        checkpoints: [
          { description: 'Names actual frameworks', points: 3 },
          { description: 'Lists real dependencies', points: 3 },
          { description: 'Identifies specific patterns', points: 4 },
        ],
      },
      {
        name: 'organization',
        maxPoints: 10,
        description: 'Consistent formatting and structure',
        checkpoints: [
          { description: 'Consistent headers', points: 3 },
          { description: 'Logical organization', points: 3 },
          { description: 'Cross-references present', points: 4 },
        ],
      },
    ],
  },
  {
    name: 'AI Utility',
    maxPoints: 30,
    criteria: [
      {
        name: 'context_summary',
        maxPoints: 10,
        description: 'ai_context.md summarizes everything',
        checkpoints: [
          { description: 'File exists', points: 2 },
          { description: 'References all major sections', points: 4 },
          { description: 'Quick navigation enabled', points: 4 },
        ],
      },
      {
        name: 'symbols',
        maxPoints: 10,
        description: 'Symbols with line numbers and context',
        checkpoints: [
          { description: 'symbols.json exists', points: 2 },
          { description: 'Has line numbers', points: 4 },
          { description: 'Context provided', points: 4 },
        ],
      },
      {
        name: 'dependencies',
        maxPoints: 10,
        description: 'Dependencies mapped accurately',
        checkpoints: [
          { description: 'dependencies.json exists', points: 2 },
          { description: 'Imports correctly mapped', points: 4 },
          { description: 'External deps identified', points: 4 },
        ],
      },
    ],
  },
  {
    name: 'Technical Accuracy',
    maxPoints: 20,
    criteria: [
      {
        name: 'languages',
        maxPoints: 5,
        description: 'Languages detected correctly',
        checkpoints: [
          { description: 'Primary language correct', points: 2 },
          { description: 'Secondary languages listed', points: 2 },
          { description: 'Language versions accurate', points: 1 },
        ],
      },
      {
        name: 'frameworks',
        maxPoints: 5,
        description: 'Frameworks detected correctly',
        checkpoints: [
          { description: 'Main framework identified', points: 2 },
          { description: 'Framework version accurate', points: 2 },
          { description: 'Sub-frameworks listed', points: 1 },
        ],
      },
      {
        name: 'entrypoints_accuracy',
        maxPoints: 5,
        description: 'Entry points are real and accurate',
        checkpoints: [
          { description: 'Files exist', points: 2 },
          { description: 'Correctly identified as entry', points: 2 },
          { description: 'Purpose described accurately', points: 1 },
        ],
      },
      {
        name: 'no_fabrication',
        maxPoints: 5,
        description: 'No fabricated or false information',
        checkpoints: [
          { description: 'No false frameworks', points: 2 },
          { description: 'No false dependencies', points: 2 },
          { description: 'No false file references', points: 1 },
        ],
      },
    ],
  },
];

export function createRubricPrompt(
  projectName: string,
  files: Record<string, string>
): string {
  const sections = AI_CONTEXT_RUBRIC.map(section => {
    const criteria = section.criteria.map(criterion => {
      const checkpoints = criterion.checkpoints
        .map(cp => `    - [ ] ${cp.description} (${cp.points} pts)`)
        .join('\n');
      
      return `\n  ${criterion.name.toUpperCase()} (${criterion.maxPoints} pts):\n${checkpoints}`;
    }).join('\n');
    
    return `\n## ${section.name.toUpperCase()} (${section.maxPoints} pts)${criteria}`;
  }).join('\n');

  const fileContents = Object.entries(files)
    .map(([name, content]) => `=== ${name} ===\n${content.substring(0, 2000)}`)
    .join('\n\n');

  return `
# AI Context Evaluation Rubric

Project: ${projectName}

Evaluate using this structured rubric. Assign points based on checkpoints.

${sections}

---

## FILES TO EVALUATE:

${fileContents}

---

## RESPONSE FORMAT (JSON ONLY):

{
  "sectionScores": {
    "File Presence": 18,
    "Content Quality": 25,
    "AI Utility": 28,
    "Technical Accuracy": 18
  },
  "criterionScores": {
    "summary": 5,
    "architecture": 4,
    ...
  },
  "totalScore": 89,
  "maxPossibleScore": 100,
  "normalizedScore": 4.45,
  "feedback": {
    "File Presence": "All files present, minor improvements needed",
    ...
  },
  "improvements": [
    "Add more specific framework versions to tech_stack.md",
    "Expand architecture.md with component diagrams",
    ...
  ]
}

Return ONLY valid JSON, no markdown formatting, no explanations.
`.trim();
}

export function parseRubricResponse(response: string): RubricEvaluation | null {
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return null;
    }

    const parsed = JSON.parse(jsonMatch[0]);

    return {
      sectionScores: parsed.sectionScores || {},
      criterionScores: parsed.criterionScores || {},
      totalScore: parsed.totalScore || 0,
      maxPossibleScore: parsed.maxPossibleScore || 100,
      normalizedScore: parsed.normalizedScore || 0,
      feedback: parsed.feedback || {},
      improvements: parsed.improvements || [],
    };
  } catch {
    return null;
  }
}

export function evaluateWithRubric(
  sectionScores: Record<string, number>,
  criterionScores: Record<string, number>,
  feedback: Record<string, string>,
  improvements: string[]
): RubricEvaluation {
  const maxPossibleScore = AI_CONTEXT_RUBRIC.reduce(
    (sum, section) => sum + section.maxPoints,
    0
  );

  const totalScore = Object.values(sectionScores).reduce(
    (sum, score) => sum + score,
    0
  );

  const normalizedScore = (totalScore / maxPossibleScore) * 5;

  return {
    sectionScores,
    criterionScores,
    totalScore,
    maxPossibleScore,
    normalizedScore,
    feedback,
    improvements: improvements.slice(0, 10),
  };
}

export function getRubricSummary(evaluation: RubricEvaluation): string {
  const sections = Object.entries(evaluation.sectionScores)
    .map(([name, score]) => {
      const maxPoints = AI_CONTEXT_RUBRIC.find(s => s.name === name)?.maxPoints || 0;
      return `  ${name}: ${score}/${maxPoints}`;
    })
    .join('\n');

  return `
Rubric Evaluation Summary
=========================
${sections}

Total: ${evaluation.totalScore}/${evaluation.maxPossibleScore}
Normalized: ${evaluation.normalizedScore.toFixed(2)}/5.0

Top Improvements:
${evaluation.improvements.map((imp, i) => `${i + 1}. ${imp}`).join('\n')}
`.trim();
}
