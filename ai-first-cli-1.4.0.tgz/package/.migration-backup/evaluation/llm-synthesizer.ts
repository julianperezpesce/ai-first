export interface SynthesisInput {
  model: string;
  improvements: string[];
  score: number;
  feedback: string;
}

export interface SynthesisResult {
  synthesizedImprovements: string[];
  groupedImprovements: Record<string, string[]>;
  prioritizedRecommendations: Array<{
    recommendation: string;
    impact: 'high' | 'medium' | 'low';
    category: string;
    sourceModels: string[];
  }>;
  duplicatesRemoved: number;
  originalCount: number;
}

export interface SimilarityGroup {
  canonical: string;
  items: Array<{
    text: string;
    model: string;
    score: number;
  }>;
}

const SIMILARITY_PATTERNS: Array<[RegExp, string, string]> = [
  [/add.*(more|better).*document/i, 'documentation', 'Improve documentation coverage'],
  [/missing.*(doc|document|comment)/i, 'documentation', 'Add missing documentation'],
  [/include.*example/i, 'examples', 'Add code examples'],
  [/add.*test/i, 'testing', 'Add test coverage'],
  [/improve.*error.*handling/i, 'error-handling', 'Improve error handling'],
  [/fix.*bug|bug.*fix/i, 'bugs', 'Fix identified bugs'],
  [/performance|optimize|slow/i, 'performance', 'Optimize performance'],
  [/structure|organize|refactor/i, 'structure', 'Improve code structure'],
  [/type.*defin|typescript/i, 'types', 'Improve type definitions'],
  [/naming|variable.*name|function.*name/i, 'naming', 'Improve naming conventions'],
  [/duplicate|redundant|remove/i, 'cleanup', 'Remove duplicates and redundancies'],
];

function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function calculateSimilarity(text1: string, text2: string): number {
  const normalized1 = normalizeText(text1);
  const normalized2 = normalizeText(text2);

  if (normalized1 === normalized2) {
    return 1.0;
  }

  const words1 = new Set(normalized1.split(' '));
  const words2 = new Set(normalized2.split(' '));

  const intersection = new Set([...words1].filter(w => words2.has(w)));
  const union = new Set([...words1, ...words2]);

  return intersection.size / union.size;
}

function categorizeImprovement(text: string): { category: string; canonical: string } {
  for (const [pattern, category, canonical] of SIMILARITY_PATTERNS) {
    if (pattern.test(text)) {
      return { category, canonical };
    }
  }

  return { category: 'general', canonical: text };
}

function determineImpact(
  count: number,
  avgModelScore: number
): 'high' | 'medium' | 'low' {
  if (count >= 2 && avgModelScore >= 3.5) {
    return 'high';
  } else if (count >= 2 || avgModelScore >= 3.5) {
    return 'medium';
  }
  return 'low';
}

export function groupSimilarImprovements(
  inputs: SynthesisInput[],
  similarityThreshold: number = 0.6
): SimilarityGroup[] {
  const allImprovements: Array<{ text: string; model: string; score: number }> = [];

  for (const input of inputs) {
    for (const improvement of input.improvements) {
      allImprovements.push({
        text: improvement,
        model: input.model,
        score: input.score,
      });
    }
  }

  const groups: SimilarityGroup[] = [];

  for (const improvement of allImprovements) {
    let added = false;

    for (const group of groups) {
      const similarity = calculateSimilarity(improvement.text, group.canonical);
      if (similarity >= similarityThreshold) {
        group.items.push(improvement);
        added = true;
        break;
      }
    }

    if (!added) {
      groups.push({
        canonical: improvement.text,
        items: [improvement],
      });
    }
  }

  return groups;
}

export function synthesizeImprovements(
  inputs: SynthesisInput[],
  maxRecommendations: number = 5
): SynthesisResult {
  const originalCount = inputs.reduce(
    (sum, input) => sum + input.improvements.length,
    0
  );

  const groups = groupSimilarImprovements(inputs);
  const groupedImprovements: Record<string, string[]> = {};
  const prioritizedRecommendations: SynthesisResult['prioritizedRecommendations'] = [];

  for (const group of groups) {
    const { category, canonical } = categorizeImprovement(group.canonical);

    if (!groupedImprovements[category]) {
      groupedImprovements[category] = [];
    }
    groupedImprovements[category].push(group.canonical);

    const sourceModels = [...new Set(group.items.map(item => item.model))];
    const avgScore =
      group.items.reduce((sum, item) => sum + item.score, 0) / group.items.length;

    prioritizedRecommendations.push({
      recommendation: canonical,
      impact: determineImpact(group.items.length, avgScore),
      category,
      sourceModels,
    });
  }

  prioritizedRecommendations.sort((a, b) => {
    const impactOrder = { high: 3, medium: 2, low: 1 };
    if (impactOrder[a.impact] !== impactOrder[b.impact]) {
      return impactOrder[b.impact] - impactOrder[a.impact];
    }
    return b.sourceModels.length - a.sourceModels.length;
  });

  const topRecommendations = prioritizedRecommendations.slice(0, maxRecommendations);
  const synthesizedImprovements = topRecommendations.map(r => r.recommendation);

  const duplicatesRemoved = originalCount - groups.length;

  return {
    synthesizedImprovements,
    groupedImprovements,
    prioritizedRecommendations: topRecommendations,
    duplicatesRemoved,
    originalCount,
  };
}

export async function synthesizeWithLLM(
  inputs: SynthesisInput[],
  llmCaller: (prompt: string) => Promise<string>,
  maxRecommendations: number = 5
): Promise<SynthesisResult> {
  const localSynthesis = synthesizeImprovements(inputs, maxRecommendations * 2);

  const prompt = `
Synthesize and prioritize these improvement suggestions from ${inputs.length} AI models:

INPUTS:
${inputs.map(input => `
Model: ${input.model} (Score: ${input.score})
Improvements:
${input.improvements.map(imp => `  - ${imp}`).join('\n')}
`).join('\n')}

SIMILAR GROUPS (already identified):
${localSynthesis.prioritizedRecommendations.map(r => `
Category: ${r.category}
Impact: ${r.impact}
Sources: ${r.sourceModels.join(', ')}
Text: ${r.recommendation}
`).join('\n')}

TASKS:
1. Merge similar suggestions semantically
2. Remove duplicates
3. Prioritize by: (a) Mentioned by multiple models, (b) Higher model scores
4. Limit to ${maxRecommendations} recommendations
5. Make each recommendation actionable and specific

Return JSON:
{
  "synthesizedImprovements": ["improvement 1", "improvement 2", ...],
  "rationale": "brief explanation of prioritization"
}

Return ONLY JSON, no markdown, no explanations outside JSON.
`.trim();

  try {
    const response = await llmCaller(prompt);
    const jsonMatch = response.match(/\{[\s\S]*\}/);

    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);

      if (
        parsed.synthesizedImprovements &&
        Array.isArray(parsed.synthesizedImprovements)
      ) {
        return {
          ...localSynthesis,
          synthesizedImprovements: parsed.synthesizedImprovements.slice(
            0,
            maxRecommendations
          ),
        };
      }
    }
  } catch {
    // Fall back to local synthesis if LLM fails
  }

  return localSynthesis;
}

export function createSynthesisReport(result: SynthesisResult): string {
  const sections = Object.entries(result.groupedImprovements)
    .map(([category, items]) => {
      return `\n${category.toUpperCase()}:\n${items.map(item => `  - ${item}`).join('\n')}`;
    })
    .join('\n');

  const prioritized = result.prioritizedRecommendations
    .map((rec, i) => {
      return `${i + 1}. [${rec.impact.toUpperCase()}] ${rec.recommendation}
   Category: ${rec.category} | Sources: ${rec.sourceModels.join(', ')}`;
    })
    .join('\n\n');

  return `
Synthesis Report
================

Original suggestions: ${result.originalCount}
Unique groups: ${result.synthesizedImprovements.length}
Duplicates removed: ${result.duplicatesRemoved}

GROUPED BY CATEGORY:
${sections}

PRIORITIZED RECOMMENDATIONS:
${prioritized}

FINAL SYNTHESIZED LIST:
${result.synthesizedImprovements.map((imp, i) => `${i + 1}. ${imp}`).join('\n')}
`.trim();
}

export function mergeSynthesisResults(
  results: SynthesisResult[],
  maxRecommendations: number = 5
): SynthesisResult {
  const allInputs: SynthesisInput[] = [];

  for (const result of results) {
    for (const rec of result.prioritizedRecommendations) {
      allInputs.push({
        model: rec.sourceModels[0] || 'unknown',
        improvements: [rec.recommendation],
        score: rec.impact === 'high' ? 4.5 : rec.impact === 'medium' ? 3.5 : 2.5,
        feedback: '',
      });
    }
  }

  return synthesizeImprovements(allInputs, maxRecommendations);
}
